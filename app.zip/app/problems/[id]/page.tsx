"use client";

import AppShell from "@/components/layout/AppShell";
import {
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    MiniStat,
    Notice,
    PageHero,
    ProgressBar,
    SidePanel,
    StatCard
} from "@/components/ui";
import {
    DifficultyBadge,
    ProblemStatusBadge,
    ProblemTable,
    SubmissionStatusBadge,
    type Difficulty,
    type ProblemStatus,
    type SubmissionStatus
} from "@/components/domain";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";
import {
    ArrowLeft,
    ArrowRight,
    BookOpen,
    CheckCircle2,
    ChevronRight,
    Clock3,
    Code2,
    Database,
    FileCode2,
    Hash,
    Lightbulb,
    ListChecks,
    MemoryStick,
    MessageSquare,
    NotebookPen,
    RotateCcw,
    Search,
    Sparkles,
    Target,
    Timer,
    Trophy,
    XCircle
} from "lucide-react";

type ProblemCategory = "구현" | "자료구조" | "그래프" | "DP" | "문자열" | "수학";
type DetailTab = "description" | "examples" | "submissions" | "related";

type ProblemExample = {
    input: string;
    output: string;
    explanation?: string;
};

type ProblemDetail = {
    id: number;
    title: string;
    difficulty: Difficulty;
    category: ProblemCategory;
    score: number;
    status: ProblemStatus;
    solvedRate: number;
    submissions: number;
    accepted: number;
    timeLimit: string;
    memoryLimit: string;
    source: string;
    tags: string[];
    memo: string;
    description: string;
    inputDescription: string;
    outputDescription: string;
    constraints: string[];
    examples: ProblemExample[];
    hints: string[];
    recommendedOrder: number;
};

type Submission = {
    id: number;
    problemId: number;
    status: SubmissionStatus;
    language: string;
    time: string;
    memory: string;
    submittedAt: string;
    codeLength: string;
};

const PROBLEMS: ProblemDetail[] = [
    {
        id: 1000,
        title: "두 수의 합",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "solved",
        solvedRate: 69.5,
        submissions: 184,
        accepted: 128,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["implementation", "math", "입출력"],
        memo: "기본 입출력과 사칙연산을 확인하는 입문 문제입니다.",
        description: "두 정수 A와 B가 주어졌을 때, A+B를 출력하는 프로그램을 작성하세요.",
        inputDescription: "첫째 줄에 A와 B가 공백으로 구분되어 주어집니다.",
        outputDescription: "첫째 줄에 A+B를 출력합니다.",
        constraints: ["0 < A, B < 10"],
        examples: [
            {
                input: "1 2",
                output: "3",
                explanation: "1과 2를 더하면 3입니다."
            }
        ],
        hints: ["표준 입력에서 두 정수를 읽습니다.", "C++에서는 cin, Python에서는 input().split()을 사용할 수 있습니다."],
        recommendedOrder: 1
    },
    {
        id: 10871,
        title: "X보다 작은 수",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "todo",
        solvedRate: 62.1,
        submissions: 151,
        accepted: 94,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["implementation", "array", "반복문"],
        memo: "배열 순회와 조건 출력 연습에 적합합니다.",
        description: "정수 N개로 이루어진 수열 A와 정수 X가 주어집니다. A에서 X보다 작은 수를 입력받은 순서대로 출력하세요.",
        inputDescription: "첫째 줄에 N과 X가 주어집니다. 둘째 줄에 수열 A를 이루는 정수 N개가 주어집니다.",
        outputDescription: "X보다 작은 수를 입력받은 순서대로 공백으로 구분해 출력합니다.",
        constraints: ["1 ≤ N, X ≤ 10,000", "1 ≤ Aᵢ ≤ 10,000"],
        examples: [
            {
                input: "10 5\n1 10 4 9 2 3 8 5 7 6",
                output: "1 4 2 3",
                explanation: "5보다 작은 값만 순서대로 출력합니다."
            }
        ],
        hints: ["배열을 전부 저장하지 않고 입력받으면서 바로 출력해도 됩니다.", "출력 형식의 공백 처리를 조심하세요."],
        recommendedOrder: 2
    },
    {
        id: 10828,
        title: "스택 명령 처리",
        difficulty: "Medium",
        category: "자료구조",
        score: 150,
        status: "solved",
        solvedRate: 60.5,
        submissions: 119,
        accepted: 72,
        timeLimit: "2초",
        memoryLimit: "512MB",
        source: "local",
        tags: ["stack", "data-structure", "자료구조"],
        memo: "스택 명령 처리와 입출력 최적화를 연습합니다.",
        description: "정수를 저장하는 스택을 구현한 다음, 입력으로 주어지는 명령을 처리하는 프로그램을 작성하세요.",
        inputDescription: "첫째 줄에 명령의 수 N이 주어집니다. 이후 N개의 줄에 명령이 하나씩 주어집니다.",
        outputDescription: "출력해야 하는 명령이 주어질 때마다 한 줄에 하나씩 결과를 출력합니다.",
        constraints: ["1 ≤ N ≤ 100,000", "주어지는 정수는 1 이상 100,000 이하입니다."],
        examples: [
            {
                input: "7\npush 1\npush 2\ntop\nsize\nempty\npop\npop",
                output: "2\n2\n0\n2\n1",
                explanation: "push로 값을 넣고 top, size, empty, pop 명령을 순서대로 처리합니다."
            }
        ],
        hints: ["빈 스택에서 pop/top이 들어올 수 있습니다.", "C++에서는 ios::sync_with_stdio(false)를 권장합니다."],
        recommendedOrder: 4
    },
    {
        id: 9012,
        title: "괄호",
        difficulty: "Medium",
        category: "자료구조",
        score: 130,
        status: "review",
        solvedRate: 54.2,
        submissions: 132,
        accepted: 71,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["stack", "string"],
        memo: "닫는 괄호가 나왔을 때 빈 스택이면 실패입니다.",
        description: "괄호 문자열이 올바른 괄호 문자열인지 판단하는 프로그램을 작성하세요.",
        inputDescription: "첫째 줄에 테스트 케이스 수 T가 주어지고, 이후 각 줄에 괄호 문자열이 주어집니다.",
        outputDescription: "각 테스트 케이스마다 올바르면 YES, 아니면 NO를 출력합니다.",
        constraints: ["괄호 문자열의 길이는 2 이상 50 이하입니다."],
        examples: [
            {
                input: "3\n(())())\n(((()())()\n(()())((()))",
                output: "NO\nNO\nYES",
                explanation: "각 문자열을 왼쪽부터 검사하며 스택 상태를 확인합니다."
            }
        ],
        hints: ["닫는 괄호가 나왔을 때 스택이 비어 있으면 바로 실패입니다.", "마지막에 스택이 비어 있어야 성공입니다."],
        recommendedOrder: 5
    },
    {
        id: 2178,
        title: "미로 탐색",
        difficulty: "Medium",
        category: "그래프",
        score: 150,
        status: "todo",
        solvedRate: 44.7,
        submissions: 115,
        accepted: 51,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["bfs", "graph", "grid"],
        memo: "격자 BFS의 기본 문제입니다.",
        description: "N×M 크기의 미로가 주어졌을 때, (1, 1)에서 출발해 (N, M)으로 이동하는 최소 칸 수를 구하세요.",
        inputDescription: "첫째 줄에 N과 M이 주어지고, 다음 N개의 줄에 M개의 숫자로 미로가 주어집니다.",
        outputDescription: "지나야 하는 최소 칸 수를 출력합니다.",
        constraints: ["2 ≤ N, M ≤ 100", "1은 이동할 수 있는 칸, 0은 이동할 수 없는 칸입니다."],
        examples: [
            {
                input: "4 6\n101111\n101010\n101011\n111011",
                output: "15",
                explanation: "BFS로 각 칸까지의 최단 거리를 구합니다."
            }
        ],
        hints: ["BFS는 처음 도착한 거리가 최단 거리입니다.", "방문 처리는 큐에 넣는 순간 하는 것이 안전합니다."],
        recommendedOrder: 7
    },
    {
        id: 7576,
        title: "토마토",
        difficulty: "Medium",
        category: "그래프",
        score: 180,
        status: "wrong",
        solvedRate: 45.8,
        submissions: 96,
        accepted: 44,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["bfs", "queue", "graph"],
        memo: "다중 시작점 BFS입니다. 모든 익은 토마토를 큐에 넣어야 합니다.",
        description: "토마토가 보관된 상자에서 하루가 지나면 익은 토마토의 인접한 토마토가 익습니다. 모든 토마토가 익는 최소 날짜를 구하세요.",
        inputDescription: "첫째 줄에 M과 N이 주어지고, 다음 N개의 줄에 상자 상태가 주어집니다.",
        outputDescription: "모든 토마토가 익는 최소 일수를 출력합니다. 불가능하면 -1을 출력합니다.",
        constraints: ["2 ≤ M, N ≤ 1,000", "1은 익은 토마토, 0은 익지 않은 토마토, -1은 빈 칸입니다."],
        examples: [
            {
                input: "6 4\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 1",
                output: "8",
                explanation: "처음 익어 있는 모든 토마토를 큐에 넣고 BFS를 시작합니다."
            }
        ],
        hints: ["시작점이 여러 개입니다.", "마지막에 0이 남아 있으면 -1입니다."],
        recommendedOrder: 8
    },
    {
        id: 1463,
        title: "1로 만들기",
        difficulty: "Medium",
        category: "DP",
        score: 140,
        status: "todo",
        solvedRate: 49.5,
        submissions: 178,
        accepted: 88,
        timeLimit: "1초",
        memoryLimit: "256MB",
        source: "local",
        tags: ["dp", "dynamic-programming"],
        memo: "dp[i]를 i를 1로 만드는 최소 연산 수로 정의합니다.",
        description: "정수 X에 사용할 수 있는 연산 3가지를 이용해 1을 만들려고 합니다. 연산 횟수의 최솟값을 구하세요.",
        inputDescription: "첫째 줄에 정수 X가 주어집니다.",
        outputDescription: "연산 횟수의 최솟값을 출력합니다.",
        constraints: ["1 ≤ X ≤ 1,000,000"],
        examples: [
            {
                input: "10",
                output: "3",
                explanation: "10 → 9 → 3 → 1 순서로 3번 연산합니다."
            }
        ],
        hints: ["dp[i] = i를 1로 만드는 최소 연산 수로 정의합니다.", "i-1, i/2, i/3에서 올 수 있는 경우를 비교합니다."],
        recommendedOrder: 10
    },
    {
        id: 12865,
        title: "평범한 배낭",
        difficulty: "Hard",
        category: "DP",
        score: 200,
        status: "wrong",
        solvedRate: 38.1,
        submissions: 76,
        accepted: 29,
        timeLimit: "2초",
        memoryLimit: "512MB",
        source: "local",
        tags: ["dp", "knapsack"],
        memo: "1차원 DP는 무게를 뒤에서 앞으로 갱신해야 합니다.",
        description: "물건의 무게와 가치가 주어질 때, 최대 무게 K를 넘지 않으면서 얻을 수 있는 최대 가치를 구하세요.",
        inputDescription: "첫째 줄에 물품의 수 N과 버틸 수 있는 무게 K가 주어집니다. 이후 N개의 줄에 각 물건의 무게와 가치가 주어집니다.",
        outputDescription: "가방에 넣을 수 있는 물건들의 가치합의 최댓값을 출력합니다.",
        constraints: ["1 ≤ N ≤ 100", "1 ≤ K ≤ 100,000", "1 ≤ W ≤ 100,000", "0 ≤ V ≤ 1,000"],
        examples: [
            {
                input: "4 7\n6 13\n4 8\n3 6\n5 12",
                output: "14",
                explanation: "무게 4와 3인 물건을 선택하면 가치 14를 얻습니다."
            }
        ],
        hints: ["0/1 배낭 문제입니다.", "1차원 DP를 쓴다면 무게를 큰 값에서 작은 값으로 갱신해야 합니다."],
        recommendedOrder: 12
    }
];

const SUBMISSIONS: Submission[] = [
    {
        id: 202605030001,
        problemId: 1000,
        status: "accepted",
        language: "C++17",
        time: "0ms",
        memory: "2020KB",
        submittedAt: "2026.05.03 10:24",
        codeLength: "312B"
    },
    {
        id: 202605030002,
        problemId: 10828,
        status: "accepted",
        language: "C++17",
        time: "12ms",
        memory: "2144KB",
        submittedAt: "2026.05.03 10:42",
        codeLength: "812B"
    },
    {
        id: 202605030003,
        problemId: 7576,
        status: "wrong",
        language: "C++17",
        time: "8ms",
        memory: "3212KB",
        submittedAt: "2026.05.03 11:20",
        codeLength: "1342B"
    },
    {
        id: 202605030004,
        problemId: 12865,
        status: "wrong",
        language: "C++17",
        time: "20ms",
        memory: "4256KB",
        submittedAt: "2026.05.03 12:15",
        codeLength: "1020B"
    }
];

const tabLabels: Record<DetailTab, string> = {
    description: "문제 설명",
    examples: "예제",
    submissions: "제출 기록",
    related: "관련 문제"
};

function findProblem(id: number) {
    return PROBLEMS.find((problem) => problem.id === id);
}

function getRelatedProblems(problem: ProblemDetail) {
    return PROBLEMS.filter((item) => {
        if (item.id === problem.id) {
            return false;
        }

        const sameCategory = item.category === problem.category;
        const sharedTag = item.tags.some((tag) => problem.tags.includes(tag));

        return sameCategory || sharedTag;
    }).slice(0, 5);
}

function getProgressTone(status: ProblemStatus) {
    switch (status) {
        case "solved":
            return "bg-emerald-600";
        case "wrong":
            return "bg-rose-600";
        case "review":
            return "bg-blue-600";
        case "todo":
        default:
            return "bg-orange-500";
    }
}

function TabButton({
                       tab,
                       activeTab,
                       onClick
                   }: {
    tab: DetailTab;
    activeTab: DetailTab;
    onClick: (tab: DetailTab) => void;
}) {
    return (
        <button
            type="button"
            onClick={() => onClick(tab)}
            className={`rounded-2xl px-4 py-3 text-sm font-black transition ${
                activeTab === tab
                    ? "bg-slate-950 text-white"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-950"
            }`}
        >
            {tabLabels[tab]}
        </button>
    );
}

function DescriptionTab({ problem }: { problem: ProblemDetail }) {
    return (
        <div className="space-y-4">
            <Card className="p-6">
                <h3 className="text-xl font-black text-slate-950">문제</h3>
                <p className="mt-4 whitespace-pre-wrap text-sm leading-8 text-slate-600">{problem.description}</p>
            </Card>

            <div className="grid gap-4 xl:grid-cols-2">
                <Card className="p-6">
                    <h3 className="text-xl font-black text-slate-950">입력</h3>
                    <p className="mt-4 whitespace-pre-wrap text-sm leading-8 text-slate-600">{problem.inputDescription}</p>
                </Card>

                <Card className="p-6">
                    <h3 className="text-xl font-black text-slate-950">출력</h3>
                    <p className="mt-4 whitespace-pre-wrap text-sm leading-8 text-slate-600">{problem.outputDescription}</p>
                </Card>
            </div>

            <Card className="p-6">
                <h3 className="text-xl font-black text-slate-950">제한</h3>
                <ul className="mt-4 space-y-2 text-sm leading-7 text-slate-600">
                    {problem.constraints.map((constraint) => (
                        <li key={constraint} className="flex gap-2">
                            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-600" />
                            <span>{constraint}</span>
                        </li>
                    ))}
                </ul>
            </Card>
        </div>
    );
}

function ExamplesTab({ problem }: { problem: ProblemDetail }) {
    return (
        <div className="space-y-4">
            {problem.examples.map((example, index) => (
                <Card key={index} className="overflow-hidden">
                    <div className="border-b border-slate-100 bg-slate-50 px-6 py-4">
                        <h3 className="font-black text-slate-950">예제 {index + 1}</h3>
                    </div>

                    <div className="grid gap-0 xl:grid-cols-2">
                        <ExampleBlock title="입력" value={example.input} />
                        <ExampleBlock title="출력" value={example.output} />
                    </div>

                    {example.explanation && (
                        <div className="border-t border-slate-100 p-6">
                            <h4 className="font-black text-slate-950">설명</h4>
                            <p className="mt-2 text-sm leading-7 text-slate-500">{example.explanation}</p>
                        </div>
                    )}
                </Card>
            ))}
        </div>
    );
}

function ExampleBlock({ title, value }: { title: string; value: string }) {
    return (
        <div className="border-b border-slate-100 p-6 xl:border-b-0 xl:border-r last:xl:border-r-0">
            <div className="mb-3 flex items-center justify-between">
                <h4 className="font-black text-slate-950">{title}</h4>
                <Badge>{title === "입력" ? "stdin" : "stdout"}</Badge>
            </div>
            <pre className="overflow-x-auto rounded-2xl bg-slate-950 p-4 text-sm leading-7 text-slate-100">
        <code>{value}</code>
      </pre>
        </div>
    );
}

function SubmissionsTab({ submissions }: { submissions: Submission[] }) {
    if (submissions.length === 0) {
        return (
            <EmptyState
                title="제출 기록이 없습니다."
                description="아직 이 문제에 대한 제출 기록이 없습니다. 풀이를 시작해보세요."
                icon={ListChecks}
            />
        );
    }

    return (
        <Card className="overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full min-w-[880px] text-left text-sm">
                    <thead className="border-b border-slate-100 bg-slate-50 text-xs font-black uppercase tracking-wide text-slate-400">
                    <tr>
                        <th className="px-5 py-4">제출 번호</th>
                        <th className="px-5 py-4">결과</th>
                        <th className="px-5 py-4">언어</th>
                        <th className="px-5 py-4">시간</th>
                        <th className="px-5 py-4">메모리</th>
                        <th className="px-5 py-4">코드 길이</th>
                        <th className="px-5 py-4">제출 시간</th>
                        <th className="px-5 py-4" />
                    </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                    {submissions.map((submission) => (
                        <tr key={submission.id} className="transition hover:bg-slate-50">
                            <td className="px-5 py-4 font-black text-slate-700">#{submission.id}</td>
                            <td className="px-5 py-4"><SubmissionStatusBadge value={submission.status} /></td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.language}</td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.time}</td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.memory}</td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.codeLength}</td>
                            <td className="px-5 py-4 font-bold text-slate-500">{submission.submittedAt}</td>
                            <td className="px-5 py-4 text-right">
                                <AppLinkButton href={`/submissions/${submission.id}`} size="sm" iconRight={ChevronRight}>
                                    상세
                                </AppLinkButton>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

function RelatedTab({ problem }: { problem: ProblemDetail }) {
    const relatedProblems = getRelatedProblems(problem);

    if (relatedProblems.length === 0) {
        return (
            <EmptyState
                title="관련 문제가 없습니다."
                description="같은 분류 또는 태그를 가진 문제가 아직 없습니다."
                icon={Search}
            />
        );
    }

    return (
        <ProblemTable
            problems={relatedProblems}
            showCategory
            showScore
            showSolvedRate
            showSubmissions={false}
            showLimits={false}
            showTags
        />
    );
}

function NotFoundProblem({ id }: { id: string }) {
    return (
        <AppShell title="문제를 찾을 수 없습니다" description="요청한 문제가 현재 로컬 데이터에 없습니다.">
            <EmptyState
                title={`#${id} 문제를 찾을 수 없습니다.`}
                description="문제 번호를 다시 확인하거나 문제 검색 페이지로 돌아가세요."
                icon={BookOpen}
                action={
                    <AppLinkButton href="/problems" variant="dark" icon={ArrowLeft}>
                        문제 검색으로 돌아가기
                    </AppLinkButton>
                }
            />
        </AppShell>
    );
}

export default function ProblemDetailPage() {
    const params = useParams<{ id: string }>();
    const id = String(params.id ?? "");
    const problemId = Number(id);
    const problem = Number.isFinite(problemId) ? findProblem(problemId) : undefined;
    const [activeTab, setActiveTab] = useState<DetailTab>("description");

    const problemSubmissions = useMemo(() => {
        if (!problem) {
            return [];
        }

        return SUBMISSIONS.filter((submission) => submission.problemId === problem.id);
    }, [problem]);

    if (!problem) {
        return <NotFoundProblem id={id} />;
    }

    const relatedProblems = getRelatedProblems(problem);
    const acceptedRate = Math.round((problem.accepted / Math.max(problem.submissions, 1)) * 1000) / 10;
    const progressTone = getProgressTone(problem.status);

    return (
        <AppShell title={`${problem.id}. ${problem.title}`} description={`${problem.category} · ${problem.difficulty} · ${problem.timeLimit} / ${problem.memoryLimit}`}>
            <div className="space-y-6">
                <PageHero
                    eyebrow={
                        <>
                            <Link href="/problems" className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-black text-white transition hover:bg-white/15">
                                <ArrowLeft className="h-3.5 w-3.5" />
                                문제 목록
                            </Link>
                            <Badge variant="blue">Problem #{problem.id}</Badge>
                            <Badge>{problem.category}</Badge>
                            <DifficultyBadge value={problem.difficulty} />
                            <ProblemStatusBadge value={problem.status} />
                        </>
                    }
                    title={problem.title}
                    description={problem.memo}
                    icon={BookOpen}
                    rightTitle="정답률"
                    rightValue={`${problem.solvedRate}%`}
                    rightCaption={`${problem.accepted} / ${problem.submissions} accepted`}
                    metrics={[
                        { label: "점수", value: `${problem.score}` },
                        { label: "시간", value: problem.timeLimit },
                        { label: "메모리", value: problem.memoryLimit }
                    ]}
                    actions={
                        <>
                            <AppLinkButton href={`/problems/${problem.id}/solve`} variant="primary" size="lg" iconRight={ArrowRight}>
                                풀이 시작
                            </AppLinkButton>
                            <AppLinkButton href={`/problems/${problem.id}/submissions`} variant="white" size="lg">
                                제출 기록
                            </AppLinkButton>
                        </>
                    }
                />

                <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <StatCard label="제출" value={problem.submissions.toLocaleString()} caption="이 문제 전체 제출" icon={ListChecks} />
                    <StatCard label="맞은 제출" value={problem.accepted.toLocaleString()} caption={`AC 비율 ${acceptedRate}%`} icon={CheckCircle2} tone="green" />
                    <StatCard label="시간 제한" value={problem.timeLimit} caption="채점 실행 시간" icon={Timer} tone="blue" />
                    <StatCard label="메모리 제한" value={problem.memoryLimit} caption="최대 사용 메모리" icon={MemoryStick} tone="orange" />
                </section>

                <section className="grid gap-6 2xl:grid-cols-[1fr_380px]">
                    <div className="space-y-5">
                        <Card className="p-2">
                            <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                                {(["description", "examples", "submissions", "related"] as DetailTab[]).map((tab) => (
                                    <TabButton key={tab} tab={tab} activeTab={activeTab} onClick={setActiveTab} />
                                ))}
                            </div>
                        </Card>

                        {activeTab === "description" && <DescriptionTab problem={problem} />}
                        {activeTab === "examples" && <ExamplesTab problem={problem} />}
                        {activeTab === "submissions" && <SubmissionsTab submissions={problemSubmissions} />}
                        {activeTab === "related" && <RelatedTab problem={problem} />}
                    </div>

                    <aside className="space-y-4">
                        <SidePanel title="문제 상태" badge={<ProblemStatusBadge value={problem.status} />}>
                            <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white">
                                <p className="text-sm font-black text-slate-300">정답률</p>
                                <p className="mt-1 text-5xl font-black">{problem.solvedRate}%</p>
                                <ProgressBar value={problem.solvedRate} className="mt-5 bg-white/10" barClassName={progressTone} />
                            </div>
                            <div className="mt-4 grid grid-cols-3 gap-3">
                                <MiniStat label="점수" value={`${problem.score}`} />
                                <MiniStat label="제출" value={`${problem.submissions}`} />
                                <MiniStat label="관련" value={`${relatedProblems.length}`} />
                            </div>
                        </SidePanel>

                        <SidePanel title="태그" badge={<Hash className="h-5 w-5 text-blue-600" />}>
                            <div className="flex flex-wrap gap-2">
                                {problem.tags.map((tag) => (
                                    <Link key={tag} href={`/problems?tag=${tag}`}>
                                        <Badge>{tag}</Badge>
                                    </Link>
                                ))}
                            </div>
                        </SidePanel>

                        <SidePanel title="풀이 힌트" badge={<Lightbulb className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                {problem.hints.map((hint, index) => (
                                    <div key={hint} className="flex gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-bold leading-6 text-slate-600">
                                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-xl bg-white text-xs font-black text-blue-600">{index + 1}</span>
                                        {hint}
                                    </div>
                                ))}
                            </div>
                        </SidePanel>

                        <SidePanel title="빠른 이동" badge={<Sparkles className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                <QuickLink href={`/problems/${problem.id}/solve`} label="풀이 화면" icon={Code2} />
                                <QuickLink href={`/problems/${problem.id}/submissions`} label="이 문제 제출 기록" icon={ListChecks} />
                                <QuickLink href="/notes" label="오답노트" icon={NotebookPen} />
                                <QuickLink href="/sets" label="문제 세트" icon={Target} />
                            </div>
                        </SidePanel>

                        <Notice title="MVP 구현 메모" variant="info">
                            현재 `/problems/[id]`는 샘플 문제 데이터 기반입니다. 이후 문제 HTML/Markdown 변환 데이터, 예제 입출력, 제출 DB와 연결하면 실제 문제 상세 페이지가 됩니다.
                        </Notice>
                    </aside>
                </section>
            </div>
        </AppShell>
    );
}

function QuickLink({ href, label, icon: Icon }: { href: string; label: string; icon: typeof Code2 }) {
    return (
        <Link href={href} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-blue-50 hover:text-blue-700">
      <span className="flex items-center gap-2">
        <Icon className="h-4 w-4" />
          {label}
      </span>
            <ChevronRight className="h-4 w-4" />
        </Link>
    );
}
