"use client";

import AppShell from "@/components/layout/AppShell";
import {
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    MiniStat,
    Notice,
    PageHero,
    ProgressBar,
    SidePanel,
    StatCard
} from "@/components/ui";
import {
    FilterPanel,
    FilterSelect,
    SearchInput
} from "@/components/forms";
import {
    ListHeader,
    ViewModeToggle,
    type ViewMode
} from "@/components/common";
import {
    DifficultyBadge,
    ProblemStatusBadge,
    SubmissionStatusBadge,
    type Difficulty,
    type ProblemStatus,
    type SubmissionStatus
} from "@/components/domain";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";
import {
    AlertTriangle,
    ArrowLeft,
    ArrowRight,
    BarChart3,
    BookOpen,
    CheckCircle2,
    ChevronRight,
    Clock3,
    Code2,
    FileCode2,
    Gauge,
    History,
    ListChecks,
    MemoryStick,
    NotebookPen,
    RotateCcw,
    Search,
    Send,
    Sparkles,
    Terminal,
    Timer,
    Trophy,
    XCircle
} from "lucide-react";

type ProblemCategory = "구현" | "자료구조" | "그래프" | "DP" | "문자열" | "수학";
type Language = "C++17" | "Python 3.12" | "Java 17" | "JavaScript";
type StatusFilter = "전체" | "맞았습니다" | "틀렸습니다" | "시간 초과" | "런타임 에러" | "컴파일 에러" | "채점 대기" | "채점 중";
type LanguageFilter = "전체" | Language;
type SortOption = "recent" | "oldest" | "time-asc" | "memory-asc" | "code-length-desc";

type ProblemDetail = {
    id: number;
    title: string;
    difficulty: Difficulty;
    category: ProblemCategory;
    score: number;
    status: ProblemStatus;
    solvedRate: number;
    submissions: number;
    accepted: number;
    timeLimit: string;
    memoryLimit: string;
    tags: string[];
    memo: string;
};

type ProblemSubmission = {
    id: number;
    problemId: number;
    status: SubmissionStatus;
    language: Language;
    timeMs: number | null;
    memoryKb: number | null;
    codeLength: number;
    submittedAt: string;
    submittedAtText: string;
    user: string;
    note: string;
};

const PROBLEMS: ProblemDetail[] = [
    {
        id: 1000,
        title: "두 수의 합",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "solved",
        solvedRate: 69.5,
        submissions: 184,
        accepted: 128,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["implementation", "math", "입출력"],
        memo: "기본 입출력과 사칙연산을 확인하는 입문 문제입니다."
    },
    {
        id: 10828,
        title: "스택 명령 처리",
        difficulty: "Medium",
        category: "자료구조",
        score: 150,
        status: "solved",
        solvedRate: 60.5,
        submissions: 119,
        accepted: 72,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["stack", "data-structure", "자료구조"],
        memo: "스택 명령 처리와 입출력 최적화를 연습합니다."
    },
    {
        id: 2178,
        title: "미로 탐색",
        difficulty: "Medium",
        category: "그래프",
        score: 150,
        status: "todo",
        solvedRate: 44.7,
        submissions: 115,
        accepted: 51,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "graph", "grid"],
        memo: "격자 BFS의 기본 문제입니다."
    },
    {
        id: 7576,
        title: "토마토",
        difficulty: "Medium",
        category: "그래프",
        score: 180,
        status: "wrong",
        solvedRate: 45.8,
        submissions: 96,
        accepted: 44,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "queue", "graph"],
        memo: "다중 시작점 BFS입니다. 모든 익은 토마토를 큐에 넣어야 합니다."
    },
    {
        id: 12865,
        title: "평범한 배낭",
        difficulty: "Hard",
        category: "DP",
        score: 200,
        status: "wrong",
        solvedRate: 38.1,
        submissions: 76,
        accepted: 29,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["dp", "knapsack"],
        memo: "1차원 DP는 무게를 뒤에서 앞으로 갱신해야 합니다."
    }
];

const SUBMISSIONS: ProblemSubmission[] = [
    {
        id: 202605030001,
        problemId: 1000,
        status: "accepted",
        language: "C++17",
        timeMs: 0,
        memoryKb: 2020,
        codeLength: 312,
        submittedAt: "2026-05-03T10:24:00",
        submittedAtText: "2026.05.03 10:24",
        user: "kimcode",
        note: "기본 입출력 통과"
    },
    {
        id: 202605030009,
        problemId: 1000,
        status: "accepted",
        language: "Python 3.12",
        timeMs: 4,
        memoryKb: 3120,
        codeLength: 48,
        submittedAt: "2026-05-03T10:31:00",
        submittedAtText: "2026.05.03 10:31",
        user: "kimcode",
        note: "Python 풀이 확인"
    },
    {
        id: 202605030002,
        problemId: 10828,
        status: "accepted",
        language: "C++17",
        timeMs: 12,
        memoryKb: 2144,
        codeLength: 812,
        submittedAt: "2026-05-03T10:42:00",
        submittedAtText: "2026.05.03 10:42",
        user: "kimcode",
        note: "ios::sync_with_stdio(false) 적용"
    },
    {
        id: 202605030010,
        problemId: 10828,
        status: "timeLimit",
        language: "Java 17",
        timeMs: null,
        memoryKb: 36100,
        codeLength: 1290,
        submittedAt: "2026-05-03T10:36:00",
        submittedAtText: "2026.05.03 10:36",
        user: "kimcode",
        note: "Scanner 사용으로 시간 초과"
    },
    {
        id: 202605030011,
        problemId: 2178,
        status: "pending",
        language: "C++17",
        timeMs: null,
        memoryKb: null,
        codeLength: 1420,
        submittedAt: "2026-05-03T11:05:00",
        submittedAtText: "2026.05.03 11:05",
        user: "kimcode",
        note: "채점 대기 중"
    },
    {
        id: 202605030012,
        problemId: 2178,
        status: "runtime",
        language: "C++17",
        timeMs: 3,
        memoryKb: 2060,
        codeLength: 1394,
        submittedAt: "2026-05-03T10:58:00",
        submittedAtText: "2026.05.03 10:58",
        user: "kimcode",
        note: "좌표 범위 체크 누락"
    },
    {
        id: 202605030003,
        problemId: 7576,
        status: "wrong",
        language: "C++17",
        timeMs: 8,
        memoryKb: 3212,
        codeLength: 1342,
        submittedAt: "2026-05-03T11:20:00",
        submittedAtText: "2026.05.03 11:20",
        user: "kimcode",
        note: "초기 큐에 시작점을 하나만 넣음"
    },
    {
        id: 202605030013,
        problemId: 7576,
        status: "wrong",
        language: "Python 3.12",
        timeMs: 84,
        memoryKb: 42128,
        codeLength: 1760,
        submittedAt: "2026-05-03T11:38:00",
        submittedAtText: "2026.05.03 11:38",
        user: "kimcode",
        note: "마지막 미익은 토마토 검사 누락"
    },
    {
        id: 202605030014,
        problemId: 7576,
        status: "accepted",
        language: "C++17",
        timeMs: 20,
        memoryKb: 4020,
        codeLength: 1488,
        submittedAt: "2026-05-03T12:02:00",
        submittedAtText: "2026.05.03 12:02",
        user: "kimcode",
        note: "다중 시작점 BFS 수정 후 통과"
    },
    {
        id: 202605030004,
        problemId: 12865,
        status: "wrong",
        language: "C++17",
        timeMs: 20,
        memoryKb: 4256,
        codeLength: 1020,
        submittedAt: "2026-05-03T12:15:00",
        submittedAtText: "2026.05.03 12:15",
        user: "kimcode",
        note: "1차원 DP 갱신 방향 오류"
    },
    {
        id: 202605030015,
        problemId: 12865,
        status: "compile",
        language: "JavaScript",
        timeMs: null,
        memoryKb: null,
        codeLength: 2310,
        submittedAt: "2026-05-03T12:22:00",
        submittedAtText: "2026.05.03 12:22",
        user: "kimcode",
        note: "Node.js 코드 문법 오류"
    }
];

const STATUS_OPTIONS: readonly StatusFilter[] = ["전체", "맞았습니다", "틀렸습니다", "시간 초과", "런타임 에러", "컴파일 에러", "채점 대기", "채점 중"];
const LANGUAGE_OPTIONS: readonly LanguageFilter[] = ["전체", "C++17", "Python 3.12", "Java 17", "JavaScript"];
const SORT_OPTIONS: readonly SortOption[] = ["recent", "oldest", "time-asc", "memory-asc", "code-length-desc"];

const statusLabelToValue: Record<Exclude<StatusFilter, "전체">, SubmissionStatus> = {
    "맞았습니다": "accepted",
    "틀렸습니다": "wrong",
    "시간 초과": "timeLimit",
    "런타임 에러": "runtime",
    "컴파일 에러": "compile",
    "채점 대기": "pending",
    "채점 중": "judging"
};

const sortLabels: Record<SortOption, string> = {
    recent: "최근 제출순",
    oldest: "오래된 제출순",
    "time-asc": "실행 시간 낮은순",
    "memory-asc": "메모리 낮은순",
    "code-length-desc": "코드 길이 긴순"
};

function findProblem(id: number) {
    return PROBLEMS.find((problem) => problem.id === id);
}

function formatTime(timeMs: number | null) {
    return timeMs === null ? "-" : `${timeMs}ms`;
}

function formatMemory(memoryKb: number | null) {
    if (memoryKb === null) {
        return "-";
    }

    return `${memoryKb.toLocaleString()}KB`;
}

function getAverageTime(submissions: ProblemSubmission[]) {
    const values = submissions.map((item) => item.timeMs).filter((value): value is number => value !== null);
    if (values.length === 0) {
        return 0;
    }

    return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function getAverageMemory(submissions: ProblemSubmission[]) {
    const values = submissions.map((item) => item.memoryKb).filter((value): value is number => value !== null);
    if (values.length === 0) {
        return 0;
    }

    return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function NotFoundProblem({ id }: { id: string }) {
    return (
        <AppShell title="문제를 찾을 수 없습니다" description="요청한 문제가 현재 로컬 데이터에 없습니다.">
            <EmptyState
                title={`#${id} 문제를 찾을 수 없습니다.`}
                description="문제 번호를 다시 확인하거나 문제 검색 페이지로 돌아가세요."
                icon={BookOpen}
                action={
                    <AppLinkButton href="/problems" variant="dark" icon={ArrowLeft}>
                        문제 검색으로 돌아가기
                    </AppLinkButton>
                }
            />
        </AppShell>
    );
}

function SubmissionCard({ submission }: { submission: ProblemSubmission }) {
    return (
        <Card hover className="p-5">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                <div className="min-w-0">
                    <div className="mb-3 flex flex-wrap items-center gap-2">
                        <SubmissionStatusBadge value={submission.status} />
                        <Badge variant="blue">{submission.language}</Badge>
                        <Badge>#{submission.id}</Badge>
                    </div>

                    <Link href={`/submissions/${submission.id}`} className="text-xl font-black text-slate-950 transition hover:text-blue-600">
                        제출 #{submission.id}
                    </Link>
                    <p className="mt-2 text-sm leading-7 text-slate-500">{submission.note}</p>
                </div>

                <div className="grid min-w-full grid-cols-2 gap-3 sm:min-w-[360px]">
                    <MetricBox label="시간" value={formatTime(submission.timeMs)} />
                    <MetricBox label="메모리" value={formatMemory(submission.memoryKb)} />
                    <MetricBox label="코드" value={`${submission.codeLength.toLocaleString()}B`} />
                    <MetricBox label="제출자" value={submission.user} />
                </div>
            </div>

            <div className="mt-5 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                    <Clock3 className="h-4 w-4" />
                    {submission.submittedAtText}
                </div>
                <div className="flex flex-wrap gap-2">
                    <AppLinkButton href={`/submissions/${submission.id}`} variant="secondary" iconRight={ChevronRight}>
                        제출 상세
                    </AppLinkButton>
                    <AppLinkButton href={`/problems/${submission.problemId}/solve`} variant="primary" iconRight={ArrowRight}>
                        다시 풀기
                    </AppLinkButton>
                </div>
            </div>
        </Card>
    );
}

function MetricBox({ label, value }: { label: string; value: string }) {
    return (
        <div className="rounded-2xl bg-slate-50 p-4">
            <p className="text-xs font-bold text-slate-400">{label}</p>
            <p className="mt-1 font-black text-slate-950">{value}</p>
        </div>
    );
}

function SubmissionsTable({ submissions }: { submissions: ProblemSubmission[] }) {
    return (
        <Card className="overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full min-w-[1080px] text-left text-sm">
                    <thead className="border-b border-slate-100 bg-slate-50 text-xs font-black uppercase tracking-wide text-slate-400">
                    <tr>
                        <th className="px-5 py-4">제출 번호</th>
                        <th className="px-5 py-4">결과</th>
                        <th className="px-5 py-4">언어</th>
                        <th className="px-5 py-4 text-right">시간</th>
                        <th className="px-5 py-4 text-right">메모리</th>
                        <th className="px-5 py-4 text-right">코드 길이</th>
                        <th className="px-5 py-4">제출자</th>
                        <th className="px-5 py-4">제출 시간</th>
                        <th className="px-5 py-4" />
                    </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-100">
                    {submissions.map((submission) => (
                        <tr key={submission.id} className="transition hover:bg-slate-50">
                            <td className="px-5 py-4">
                                <Link href={`/submissions/${submission.id}`} className="font-black text-slate-950 transition hover:text-blue-600">
                                    #{submission.id}
                                </Link>
                                <p className="mt-1 line-clamp-1 text-xs font-bold text-slate-400">{submission.note}</p>
                            </td>
                            <td className="px-5 py-4"><SubmissionStatusBadge value={submission.status} /></td>
                            <td className="px-5 py-4"><Badge variant="blue">{submission.language}</Badge></td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{formatTime(submission.timeMs)}</td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{formatMemory(submission.memoryKb)}</td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{submission.codeLength.toLocaleString()}B</td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.user}</td>
                            <td className="px-5 py-4 font-bold text-slate-500">{submission.submittedAtText}</td>
                            <td className="px-5 py-4 text-right">
                                <AppLinkButton href={`/submissions/${submission.id}`} size="sm" iconRight={ChevronRight}>
                                    상세
                                </AppLinkButton>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

function StatusDistributionPanel({ submissions }: { submissions: ProblemSubmission[] }) {
    const accepted = submissions.filter((item) => item.status === "accepted").length;
    const wrong = submissions.filter((item) => item.status === "wrong").length;
    const error = submissions.filter((item) => item.status === "compile" || item.status === "runtime" || item.status === "timeLimit").length;
    const pending = submissions.filter((item) => item.status === "pending" || item.status === "judging").length;
    const total = Math.max(submissions.length, 1);

    return (
        <SidePanel title="결과 분포" badge={<Gauge className="h-5 w-5 text-blue-600" />}>
            <div className="space-y-4">
                <DistributionRow label="맞았습니다" value={accepted} total={total} barClassName="bg-emerald-600" icon={CheckCircle2} />
                <DistributionRow label="틀렸습니다" value={wrong} total={total} barClassName="bg-rose-600" icon={XCircle} />
                <DistributionRow label="에러 / 초과" value={error} total={total} barClassName="bg-orange-500" icon={AlertTriangle} />
                <DistributionRow label="대기 / 채점" value={pending} total={total} barClassName="bg-blue-600" icon={RotateCcw} />
            </div>
        </SidePanel>
    );
}

function DistributionRow({ label, value, total, barClassName, icon: Icon }: { label: string; value: number; total: number; barClassName: string; icon: typeof CheckCircle2 }) {
    const percent = Math.round((value / total) * 100);

    return (
        <div>
            <div className="mb-2 flex items-center justify-between text-sm font-black">
                <span className="flex items-center gap-2 text-slate-700"><Icon className="h-4 w-4" />{label}</span>
                <span className="text-slate-500">{value}개</span>
            </div>
            <ProgressBar value={percent} barClassName={barClassName} />
        </div>
    );
}

function QuickLink({ href, label, icon: Icon }: { href: string; label: string; icon: typeof BookOpen }) {
    return (
        <Link href={href} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-blue-50 hover:text-blue-700">
      <span className="flex items-center gap-2">
        <Icon className="h-4 w-4" />
          {label}
      </span>
            <ChevronRight className="h-4 w-4" />
        </Link>
    );
}

export default function ProblemSubmissionsPage() {
    const params = useParams<{ id: string }>();
    const id = String(params.id ?? "");
    const problemId = Number(id);
    const problem = Number.isFinite(problemId) ? findProblem(problemId) : undefined;

    const [keyword, setKeyword] = useState("");
    const [status, setStatus] = useState<StatusFilter>("전체");
    const [language, setLanguage] = useState<LanguageFilter>("전체");
    const [sort, setSort] = useState<SortOption>("recent");
    const [viewMode, setViewMode] = useState<ViewMode>("table");

    const problemSubmissions = useMemo(() => {
        if (!problem) {
            return [];
        }

        return SUBMISSIONS.filter((submission) => submission.problemId === problem.id);
    }, [problem]);

    const filteredSubmissions = useMemo(() => {
        const lowerKeyword = keyword.trim().toLowerCase();

        const result = problemSubmissions.filter((submission) => {
            const matchesKeyword =
                !lowerKeyword ||
                String(submission.id).includes(lowerKeyword) ||
                submission.user.toLowerCase().includes(lowerKeyword) ||
                submission.language.toLowerCase().includes(lowerKeyword) ||
                submission.note.toLowerCase().includes(lowerKeyword);

            const matchesStatus = status === "전체" || submission.status === statusLabelToValue[status];
            const matchesLanguage = language === "전체" || submission.language === language;

            return matchesKeyword && matchesStatus && matchesLanguage;
        });

        return result.sort((a, b) => {
            switch (sort) {
                case "oldest":
                    return a.submittedAt.localeCompare(b.submittedAt);
                case "time-asc":
                    return (a.timeMs ?? Number.MAX_SAFE_INTEGER) - (b.timeMs ?? Number.MAX_SAFE_INTEGER);
                case "memory-asc":
                    return (a.memoryKb ?? Number.MAX_SAFE_INTEGER) - (b.memoryKb ?? Number.MAX_SAFE_INTEGER);
                case "code-length-desc":
                    return b.codeLength - a.codeLength;
                case "recent":
                default:
                    return b.submittedAt.localeCompare(a.submittedAt);
            }
        });
    }, [keyword, status, language, sort, problemSubmissions]);

    if (!problem) {
        return <NotFoundProblem id={id} />;
    }

    const acceptedCount = problemSubmissions.filter((submission) => submission.status === "accepted").length;
    const wrongCount = problemSubmissions.filter((submission) => submission.status === "wrong").length;
    const errorCount = problemSubmissions.filter((submission) => submission.status === "compile" || submission.status === "runtime" || submission.status === "timeLimit").length;
    const acceptedRate = problemSubmissions.length === 0 ? 0 : Math.round((acceptedCount / problemSubmissions.length) * 1000) / 10;
    const averageTime = getAverageTime(problemSubmissions);
    const averageMemory = getAverageMemory(problemSubmissions);

    const resetFilters = () => {
        setKeyword("");
        setStatus("전체");
        setLanguage("전체");
        setSort("recent");
    };

    return (
        <AppShell title={`${problem.id}. ${problem.title} 제출 기록`} description={`${problem.category} · ${problem.difficulty} · 제출 ${problemSubmissions.length}개`}>
            <div className="space-y-6">
                <PageHero
                    eyebrow={
                        <>
                            <Link href={`/problems/${problem.id}`} className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-black text-white transition hover:bg-white/15">
                                <ArrowLeft className="h-3.5 w-3.5" />
                                문제 상세
                            </Link>
                            <Badge variant="blue">Submissions</Badge>
                            <Badge>{problem.category}</Badge>
                            <DifficultyBadge value={problem.difficulty} />
                            <ProblemStatusBadge value={problem.status} />
                        </>
                    }
                    title={`${problem.title} 제출 기록`}
                    description="이 문제에 대한 제출 결과, 사용 언어, 실행 시간, 메모리, 코드 길이를 확인할 수 있습니다. 실패한 제출은 오답노트나 풀이 화면으로 바로 연결하세요."
                    icon={ListChecks}
                    rightTitle="이 문제 제출"
                    rightValue={problemSubmissions.length.toLocaleString()}
                    rightCaption={`통과율 ${acceptedRate}%`}
                    metrics={[
                        { label: "AC", value: `${acceptedCount}` },
                        { label: "WA", value: `${wrongCount}` },
                        { label: "Error", value: `${errorCount}` }
                    ]}
                    actions={
                        <>
                            <AppLinkButton href={`/problems/${problem.id}/solve`} variant="primary" size="lg" iconRight={ArrowRight}>
                                다시 풀기
                            </AppLinkButton>
                            <AppLinkButton href="/submissions" variant="white" size="lg">
                                전체 제출 기록
                            </AppLinkButton>
                        </>
                    }
                />

                <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <StatCard label="제출" value={problemSubmissions.length.toLocaleString()} caption="현재 사용자 기준" icon={ListChecks} />
                    <StatCard label="맞았습니다" value={acceptedCount.toLocaleString()} caption={`통과율 ${acceptedRate}%`} icon={CheckCircle2} tone="green" />
                    <StatCard label="평균 시간" value={`${averageTime}ms`} caption="실행 완료 제출 기준" icon={Timer} tone="blue" />
                    <StatCard label="평균 메모리" value={formatMemory(averageMemory)} caption="실행 완료 제출 기준" icon={MemoryStick} tone="orange" />
                </section>

                <FilterPanel
                    title="제출 기록 검색 / 필터"
                    onReset={resetFilters}
                    gridClassName="grid gap-3 xl:grid-cols-[1.4fr_180px_180px_190px_auto] xl:items-end"
                >
                    <SearchInput
                        value={keyword}
                        onChange={setKeyword}
                        placeholder="제출 번호, 언어, 사용자, 메모 검색"
                    />
                    <FilterSelect label="결과" value={status} onChange={setStatus} options={STATUS_OPTIONS} />
                    <FilterSelect label="언어" value={language} onChange={setLanguage} options={LANGUAGE_OPTIONS} />
                    <FilterSelect label="정렬" value={sort} onChange={setSort} options={SORT_OPTIONS} />
                </FilterPanel>

                <section className="grid gap-6 2xl:grid-cols-[1fr_380px]">
                    <div className="space-y-4">
                        <ListHeader
                            title="제출 목록"
                            description={`검색 조건에 맞는 제출 ${filteredSubmissions.length.toLocaleString()}개가 표시됩니다. 현재 정렬: ${sortLabels[sort]}`}
                            right={<ViewModeToggle value={viewMode} onChange={setViewMode} />}
                        />

                        {filteredSubmissions.length === 0 ? (
                            <EmptyState
                                title="제출 기록을 찾을 수 없습니다."
                                description="검색어 또는 필터 조건을 변경해보세요."
                                icon={Search}
                                onReset={resetFilters}
                            />
                        ) : viewMode === "card" ? (
                            <div className="space-y-4">
                                {filteredSubmissions.map((submission) => <SubmissionCard key={submission.id} submission={submission} />)}
                            </div>
                        ) : (
                            <SubmissionsTable submissions={filteredSubmissions} />
                        )}
                    </div>

                    <aside className="space-y-4">
                        <SidePanel title="문제 요약" badge={<BookOpen className="h-5 w-5 text-blue-600" />}>
                            <p className="text-sm leading-7 text-slate-600">{problem.memo}</p>
                            <div className="mt-4 grid grid-cols-2 gap-3">
                                <MiniStat label="난이도" value={problem.difficulty} />
                                <MiniStat label="점수" value={`${problem.score}`} />
                                <MiniStat label="시간" value={problem.timeLimit} />
                                <MiniStat label="메모리" value={problem.memoryLimit} />
                            </div>
                        </SidePanel>

                        <StatusDistributionPanel submissions={problemSubmissions} />

                        <SidePanel title="태그" badge={<BarChart3 className="h-5 w-5 text-blue-600" />}>
                            <div className="flex flex-wrap gap-2">
                                {problem.tags.map((tag) => (
                                    <Link key={tag} href={`/problems?tag=${tag}`}>
                                        <Badge>{tag}</Badge>
                                    </Link>
                                ))}
                            </div>
                        </SidePanel>

                        <SidePanel title="빠른 이동" badge={<Sparkles className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                <QuickLink href={`/problems/${problem.id}`} label="문제 상세" icon={BookOpen} />
                                <QuickLink href={`/problems/${problem.id}/solve`} label="풀이 화면" icon={Code2} />
                                <QuickLink href="/submissions" label="전체 제출 기록" icon={History} />
                                <QuickLink href="/notes" label="오답노트" icon={NotebookPen} />
                            </div>
                        </SidePanel>

                        <Notice title="MVP 구현 메모" variant="info">
                            현재 `/problems/[id]/submissions`는 샘플 제출 데이터 기반입니다. 실제 연결 시에는 `GET /api/problems/:id/submissions`와 `GET /api/submissions/:id`를 붙이면 됩니다.
                        </Notice>
                    </aside>
                </section>
            </div>
        </AppShell>
    );
}
