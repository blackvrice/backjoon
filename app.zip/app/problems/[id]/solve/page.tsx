"use client";

import AppShell from "@/components/layout/AppShell";
import {
    AppButton,
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    Notice,
    SidePanel
} from "@/components/ui";
import { FilterSelect } from "@/components/forms";
import {
    DifficultyBadge,
    ProblemStatusBadge,
    SubmissionStatusBadge,
    type Difficulty,
    type ProblemStatus,
    type SubmissionStatus
} from "@/components/domain";
import JudgeMonacoEditor from "@/components/editor/JudgeMonacoEditor";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";
import type { ComponentType } from "react";
import {
    ArrowLeft,
    BookOpen,
    ChevronRight,
    Clipboard,
    Clock3,
    Copy,
    FileCode2,
    History,
    ListChecks,
    MemoryStick,
    NotebookPen,
    Play,
    RotateCcw,
    Save,
    Send,
    ShieldCheck,
    Terminal,
    Timer,
    Trophy
} from "lucide-react";

type ProblemCategory = "구현" | "자료구조" | "그래프" | "DP" | "문자열" | "수학";

type Language =
    | "C++17"
    | "Python 3.12"
    | "Java 17"
    | "JavaScript"
    | "Dart"
    | "C# 12";

type RunStatus = "idle" | "running" | "accepted" | "wrong" | "compile";
type ProblemTab = "description" | "examples" | "hints";
type ConsoleTab = "result" | "custom" | "settings";

type ProblemExample = {
    input: string;
    output: string;
    explanation?: string;
};

type ProblemDetail = {
    id: number;
    title: string;
    difficulty: Difficulty;
    category: ProblemCategory;
    score: number;
    status: ProblemStatus;
    solvedRate: number;
    submissions: number;
    accepted: number;
    timeLimit: string;
    memoryLimit: string;
    tags: string[];
    memo: string;
    description: string;
    inputDescription: string;
    outputDescription: string;
    constraints: string[];
    examples: ProblemExample[];
    hints: string[];
};

type JudgeResult = {
    id: string;
    label: string;
    status: SubmissionStatus;
    time: string;
    memory: string;
    message: string;
};

type JudgeMode = "run" | "submit";

type JudgeApiStatus =
    | "accepted"
    | "wrong"
    | "compile"
    | "runtime"
    | "timeLimit"
    | "memoryLimit"
    | "pending"
    | "judging";

type JudgeApiCaseResult = {
    id?: string;
    label?: string;
    status: JudgeApiStatus;
    timeMs?: number;
    memoryKb?: number;
    message?: string;
    input?: string;
    expectedOutput?: string;
    actualOutput?: string;
};

type JudgeApiResponse = {
    status: JudgeApiStatus;
    message?: string;
    results: JudgeApiCaseResult[];
};

const PROBLEMS: ProblemDetail[] = [
    {
        id: 1000,
        title: "두 수의 합",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "solved",
        solvedRate: 69.5,
        submissions: 184,
        accepted: 128,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["implementation", "math", "입출력"],
        memo: "기본 입출력과 사칙연산을 확인하는 입문 문제입니다.",
        description: "두 정수 A와 B가 주어졌을 때, A+B를 출력하는 프로그램을 작성하세요.",
        inputDescription: "첫째 줄에 A와 B가 공백으로 구분되어 주어집니다.",
        outputDescription: "첫째 줄에 A+B를 출력합니다.",
        constraints: ["0 < A, B < 10"],
        examples: [
            {
                input: "1 2",
                output: "3",
                explanation: "1과 2를 더하면 3입니다."
            }
        ],
        hints: [
            "표준 입력에서 두 정수를 읽습니다.",
            "C++에서는 cin, Python에서는 input().split()을 사용할 수 있습니다."
        ]
    },
    {
        id: 10828,
        title: "스택 명령 처리",
        difficulty: "Medium",
        category: "자료구조",
        score: 150,
        status: "solved",
        solvedRate: 60.5,
        submissions: 119,
        accepted: 72,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["stack", "data-structure", "자료구조"],
        memo: "스택 명령 처리와 입출력 최적화를 연습합니다.",
        description: "정수를 저장하는 스택을 구현한 다음, 입력으로 주어지는 명령을 처리하는 프로그램을 작성하세요.",
        inputDescription: "첫째 줄에 명령의 수 N이 주어집니다. 이후 N개의 줄에 명령이 하나씩 주어집니다.",
        outputDescription: "출력해야 하는 명령이 주어질 때마다 한 줄에 하나씩 결과를 출력합니다.",
        constraints: ["1 ≤ N ≤ 100,000", "주어지는 정수는 1 이상 100,000 이하입니다."],
        examples: [
            {
                input: "7\npush 1\npush 2\ntop\nsize\nempty\npop\npop",
                output: "2\n2\n0\n2\n1",
                explanation: "push로 값을 넣고 top, size, empty, pop 명령을 순서대로 처리합니다."
            }
        ],
        hints: [
            "빈 스택에서 pop/top이 들어올 수 있습니다.",
            "C++에서는 ios::sync_with_stdio(false)를 권장합니다."
        ]
    },
    {
        id: 2178,
        title: "미로 탐색",
        difficulty: "Medium",
        category: "그래프",
        score: 150,
        status: "todo",
        solvedRate: 44.7,
        submissions: 115,
        accepted: 51,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "graph", "grid"],
        memo: "격자 BFS의 기본 문제입니다.",
        description: "N×M 크기의 미로가 주어졌을 때, (1, 1)에서 출발해 (N, M)으로 이동하는 최소 칸 수를 구하세요.",
        inputDescription: "첫째 줄에 N과 M이 주어지고, 다음 N개의 줄에 M개의 숫자로 미로가 주어집니다.",
        outputDescription: "지나야 하는 최소 칸 수를 출력합니다.",
        constraints: ["2 ≤ N, M ≤ 100", "1은 이동할 수 있는 칸, 0은 이동할 수 없는 칸입니다."],
        examples: [
            {
                input: "4 6\n101111\n101010\n101011\n111011",
                output: "15",
                explanation: "BFS로 각 칸까지의 최단 거리를 구합니다."
            }
        ],
        hints: [
            "BFS는 처음 도착한 거리가 최단 거리입니다.",
            "방문 처리는 큐에 넣는 순간 하는 것이 안전합니다."
        ]
    },
    {
        id: 7576,
        title: "토마토",
        difficulty: "Medium",
        category: "그래프",
        score: 180,
        status: "wrong",
        solvedRate: 45.8,
        submissions: 96,
        accepted: 44,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "queue", "graph"],
        memo: "다중 시작점 BFS입니다. 모든 익은 토마토를 큐에 넣어야 합니다.",
        description: "토마토가 보관된 상자에서 하루가 지나면 익은 토마토의 인접한 토마토가 익습니다. 모든 토마토가 익는 최소 날짜를 구하세요.",
        inputDescription: "첫째 줄에 M과 N이 주어지고, 다음 N개의 줄에 상자 상태가 주어집니다.",
        outputDescription: "모든 토마토가 익는 최소 일수를 출력합니다. 불가능하면 -1을 출력합니다.",
        constraints: [
            "2 ≤ M, N ≤ 1,000",
            "1은 익은 토마토, 0은 익지 않은 토마토, -1은 빈 칸입니다."
        ],
        examples: [
            {
                input: "6 4\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 1",
                output: "8",
                explanation: "처음 익어 있는 모든 토마토를 큐에 넣고 BFS를 시작합니다."
            }
        ],
        hints: [
            "시작점이 여러 개입니다.",
            "마지막에 0이 남아 있으면 -1입니다."
        ]
    },
    {
        id: 12865,
        title: "평범한 배낭",
        difficulty: "Hard",
        category: "DP",
        score: 200,
        status: "wrong",
        solvedRate: 38.1,
        submissions: 76,
        accepted: 29,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["dp", "knapsack"],
        memo: "1차원 DP는 무게를 뒤에서 앞으로 갱신해야 합니다.",
        description: "물건의 무게와 가치가 주어질 때, 최대 무게 K를 넘지 않으면서 얻을 수 있는 최대 가치를 구하세요.",
        inputDescription: "첫째 줄에 물품의 수 N과 버틸 수 있는 무게 K가 주어집니다. 이후 N개의 줄에 각 물건의 무게와 가치가 주어집니다.",
        outputDescription: "가방에 넣을 수 있는 물건들의 가치합의 최댓값을 출력합니다.",
        constraints: [
            "1 ≤ N ≤ 100",
            "1 ≤ K ≤ 100,000",
            "1 ≤ W ≤ 100,000",
            "0 ≤ V ≤ 1,000"
        ],
        examples: [
            {
                input: "4 7\n6 13\n4 8\n3 6\n5 12",
                output: "14",
                explanation: "무게 4와 3인 물건을 선택하면 가치 14를 얻습니다."
            }
        ],
        hints: [
            "0/1 배낭 문제입니다.",
            "1차원 DP를 쓴다면 무게를 큰 값에서 작은 값으로 갱신해야 합니다."
        ]
    }
];

const LANGUAGE_OPTIONS: readonly Language[] = [
    "C++17",
    "Python 3.12",
    "Java 17",
    "JavaScript",
    "Dart",
    "C# 12"
];

const DEFAULT_CODE: Record<Language, string> = {
    "C++17": `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int a, b;
    cin >> a >> b;
    cout << a + b << '\\n';
    return 0;
}
`,
    "Python 3.12": `a, b = map(int, input().split())
print(a + b)
`,
    "Java 17": `import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int a = Integer.parseInt(st.nextToken());
        int b = Integer.parseInt(st.nextToken());
        System.out.println(a + b);
    }
}
`,
    JavaScript: `const fs = require("fs");
const input = fs.readFileSync(0, "utf8").trim().split(/\\s+/).map(Number);
console.log(input[0] + input[1]);
`,
    Dart: `import 'dart:io';

void main() {
  final input = stdin.readAsStringSync().trim().split(RegExp(r'\\s+'));

  final a = int.parse(input[0]);
  final b = int.parse(input[1]);

  print(a + b);
}
`,
    "C# 12": `using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        var input = Console.In.ReadToEnd()
            .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToArray();

        Console.WriteLine(input[0] + input[1]);
    }
}
`
};

const languageSettings: Record<Language, { compile: string; run: string; ext: string }> = {
    "C++17": {
        compile: "g++ -std=c++17 -O2 -pipe",
        run: "./main",
        ext: "cpp"
    },
    "Python 3.12": {
        compile: "-",
        run: "python3 main.py",
        ext: "py"
    },
    "Java 17": {
        compile: "javac Main.java",
        run: "java Main",
        ext: "java"
    },
    JavaScript: {
        compile: "-",
        run: "node main.js",
        ext: "js"
    },
    Dart: {
        compile: "-",
        run: "dart main.dart",
        ext: "dart"
    },
    "C# 12": {
        compile: "dotnet build -c Release",
        run: "dotnet run -c Release --no-build",
        ext: "cs"
    }
};

const monacoLanguageMap: Record<Language, string> = {
    "C++17": "cpp",
    "Python 3.12": "python",
    "Java 17": "java",
    JavaScript: "javascript",
    Dart: "dart",
    "C# 12": "csharp"
};

const problemTabLabels: Record<ProblemTab, string> = {
    description: "문제",
    examples: "예제",
    hints: "힌트"
};

const consoleTabLabels: Record<ConsoleTab, string> = {
    result: "실행 결과",
    custom: "사용자 입력",
    settings: "환경"
};

function findProblem(id: number) {
    return PROBLEMS.find((problem) => problem.id === id);
}

function getRunStatusNotice(status: RunStatus) {
    switch (status) {
        case "running":
            return {
                variant: "warning" as const,
                message: "코드를 실행하는 중입니다."
            };
        case "accepted":
            return {
                variant: "success" as const,
                message: "예제 실행이 통과했습니다."
            };
        case "wrong":
            return {
                variant: "danger" as const,
                message: "예제 실행 결과가 다릅니다."
            };
        case "compile":
            return {
                variant: "danger" as const,
                message: "컴파일 오류가 발생했습니다."
            };
        case "idle":
        default:
            return {
                variant: "info" as const,
                message: "아직 실행하지 않았습니다."
            };
    }
}

function toRunStatus(status: JudgeApiStatus): RunStatus {
    switch (status) {
        case "accepted":
            return "accepted";

        case "wrong":
            return "wrong";

        case "compile":
        case "runtime":
        case "timeLimit":
        case "memoryLimit":
            return "compile";

        case "pending":
        case "judging":
            return "running";

        default:
            return "idle";
    }
}

function toSubmissionStatus(status: JudgeApiStatus): SubmissionStatus {
    switch (status) {
        case "accepted":
            return "accepted";

        case "wrong":
            return "wrong";

        case "compile":
            return "compile";

        case "runtime":
            return "runtime";

        case "timeLimit":
        case "memoryLimit":
            return "timeLimit";

        case "pending":
            return "pending";

        case "judging":
            return "judging";

        default:
            return "wrong";
    }
}

function formatJudgeTime(timeMs?: number) {
    return typeof timeMs === "number" ? `${timeMs}ms` : "-";
}

function formatJudgeMemory(memoryKb?: number) {
    return typeof memoryKb === "number" ? `${memoryKb.toLocaleString()}KB` : "-";
}

async function requestJudgeApi({
                                   mode,
                                   problem,
                                   language,
                                   code,
                                   customInput
                               }: {
    mode: JudgeMode;
    problem: ProblemDetail;
    language: Language;
    code: string;
    customInput: string;
}): Promise<JudgeApiResponse> {
    const hasCustomInput = customInput.trim().length > 0;

    const tests =
        mode === "run" && hasCustomInput
            ? [
                {
                    id: "custom-1",
                    label: "사용자 입력",
                    input: customInput,
                    expectedOutput: ""
                }
            ]
            : problem.examples.map((example, index) => ({
                id: `sample-${index + 1}`,
                label: `예제 ${index + 1}`,
                input: example.input,
                expectedOutput: example.output
            }));

    const response = await fetch("/api/judge", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            mode,
            problemId: problem.id,
            problemTitle: problem.title,
            language,
            sourceFile: `Main.${languageSettings[language].ext}`,
            code,
            tests,
            timeLimit: problem.timeLimit,
            memoryLimit: problem.memoryLimit
        })
    });

    if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "채점 서버 요청에 실패했습니다.");
    }

    return response.json() as Promise<JudgeApiResponse>;
}

function convertJudgeResults(apiResults: JudgeApiCaseResult[]): JudgeResult[] {
    return apiResults.map((item, index) => ({
        id: item.id ?? `case-${index + 1}`,
        label: item.label ?? `테스트 ${index + 1}`,
        status: toSubmissionStatus(item.status),
        time: formatJudgeTime(item.timeMs),
        memory: formatJudgeMemory(item.memoryKb),
        message:
            item.message ??
            (item.status === "accepted"
                ? "정답입니다."
                : item.status === "wrong"
                    ? "출력이 정답과 다릅니다."
                    : item.status === "compile"
                        ? "컴파일 오류가 발생했습니다."
                        : "채점 결과를 확인하세요.")
    }));
}

function NotFoundProblem({ id }: { id: string }) {
    return (
        <AppShell title="문제를 찾을 수 없습니다" description="요청한 문제가 현재 로컬 데이터에 없습니다.">
            <EmptyState
                title={`#${id} 문제를 찾을 수 없습니다.`}
                description="문제 번호를 다시 확인하거나 문제 검색 페이지로 돌아가세요."
                icon={BookOpen}
                action={
                    <AppLinkButton href="/problems" variant="dark" icon={ArrowLeft}>
                        문제 검색으로 돌아가기
                    </AppLinkButton>
                }
            />
        </AppShell>
    );
}

function ExamTopBar({
                        problem,
                        language,
                        runStatus,
                        onRun,
                        onSubmit
                    }: {
    problem: ProblemDetail;
    language: Language;
    runStatus: RunStatus;
    onRun: () => void;
    onSubmit: () => void;
}) {
    return (
        <Card className="sticky top-20 z-20 overflow-hidden border-slate-200 bg-white/95 backdrop-blur-xl lg:top-[76px]">
            <div className="flex flex-col gap-3 px-4 py-3 xl:flex-row xl:items-center xl:justify-between">
                <div className="flex min-w-0 flex-wrap items-center gap-2">
                    <Link
                        href={`/problems/${problem.id}`}
                        className="inline-flex h-9 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-black text-slate-600 transition hover:bg-slate-50"
                    >
                        <ArrowLeft className="h-4 w-4" />
                        문제 상세
                    </Link>

                    <Badge variant="blue">#{problem.id}</Badge>
                    <DifficultyBadge value={problem.difficulty} />
                    <ProblemStatusBadge value={problem.status} />
                    <Badge>{problem.category}</Badge>
                    <Badge>{language}</Badge>
                </div>

                <div className="min-w-0 flex-1 xl:px-4">
                    <div className="truncate text-base font-black text-slate-950">
                        {problem.title}
                    </div>
                    <div className="mt-1 flex flex-wrap gap-3 text-xs font-bold text-slate-400">
                        <span>점수 {problem.score}</span>
                        <span>정답률 {problem.solvedRate}%</span>
                        <span>시간 {problem.timeLimit}</span>
                        <span>메모리 {problem.memoryLimit}</span>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <div className="inline-flex h-10 items-center gap-2 rounded-2xl bg-slate-100 px-3 text-sm font-black text-slate-700">
                        <Clock3 className="h-4 w-4 text-blue-600" />
                        01:58:23
                    </div>

                    <AppButton
                        variant="secondary"
                        icon={Play}
                        onClick={onRun}
                        disabled={runStatus === "running"}
                    >
                        실행
                    </AppButton>

                    <AppButton
                        variant="primary"
                        icon={Send}
                        onClick={onSubmit}
                        disabled={runStatus === "running"}
                    >
                        제출
                    </AppButton>
                </div>
            </div>
        </Card>
    );
}

function ProblemPanel({
                          problem,
                          activeTab,
                          onTabChange,
                          onUseSample
                      }: {
    problem: ProblemDetail;
    activeTab: ProblemTab;
    onTabChange: (tab: ProblemTab) => void;
    onUseSample: (input: string) => void;
}) {
    return (
        <Card className="flex min-h-[calc(100vh-190px)] flex-col overflow-hidden">
            <div className="border-b border-slate-100 bg-white p-3">
                <div className="grid grid-cols-3 gap-2">
                    {(["description", "examples", "hints"] as ProblemTab[]).map((tab) => (
                        <button
                            key={tab}
                            type="button"
                            onClick={() => onTabChange(tab)}
                            className={`rounded-2xl px-3 py-2.5 text-sm font-black transition ${
                                activeTab === tab
                                    ? "bg-slate-950 text-white"
                                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-950"
                            }`}
                        >
                            {problemTabLabels[tab]}
                        </button>
                    ))}
                </div>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto p-5">
                {activeTab === "description" && <ProblemDescription problem={problem} />}
                {activeTab === "examples" && (
                    <ProblemExamples problem={problem} onUseSample={onUseSample} />
                )}
                {activeTab === "hints" && <ProblemHints problem={problem} />}
            </div>
        </Card>
    );
}

function ProblemDescription({ problem }: { problem: ProblemDetail }) {
    return (
        <div className="space-y-5">
            <div>
                <div className="mb-3 flex flex-wrap items-center gap-2">
                    {problem.tags.map((tag) => (
                        <Link key={tag} href={`/problems?tag=${tag}`}>
                            <Badge>{tag}</Badge>
                        </Link>
                    ))}
                </div>

                <h2 className="text-2xl font-black text-slate-950">{problem.title}</h2>
                <p className="mt-4 text-sm leading-8 text-slate-600">{problem.description}</p>
            </div>

            <section className="rounded-3xl bg-slate-50 p-5">
                <h3 className="font-black text-slate-950">입력</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">
                    {problem.inputDescription}
                </p>
            </section>

            <section className="rounded-3xl bg-slate-50 p-5">
                <h3 className="font-black text-slate-950">출력</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">
                    {problem.outputDescription}
                </p>
            </section>

            <section className="rounded-3xl bg-slate-50 p-5">
                <h3 className="font-black text-slate-950">제한</h3>
                <ul className="mt-3 space-y-2 text-sm leading-7 text-slate-600">
                    {problem.constraints.map((constraint) => (
                        <li key={constraint} className="flex gap-2">
                            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-600" />
                            <span>{constraint}</span>
                        </li>
                    ))}
                </ul>
            </section>
        </div>
    );
}

function ProblemExamples({
                             problem,
                             onUseSample
                         }: {
    problem: ProblemDetail;
    onUseSample: (input: string) => void;
}) {
    return (
        <div className="space-y-4">
            {problem.examples.map((example, index) => (
                <Card key={index} className="overflow-hidden">
                    <div className="border-b border-slate-100 bg-slate-50 px-4 py-3">
                        <div className="flex items-center justify-between gap-3">
                            <h3 className="font-black text-slate-950">예제 {index + 1}</h3>
                            <AppButton
                                variant="secondary"
                                size="sm"
                                icon={Clipboard}
                                onClick={() => onUseSample(example.input)}
                            >
                                입력 사용
                            </AppButton>
                        </div>
                    </div>

                    <ExampleBlock title="입력" value={example.input} />
                    <ExampleBlock title="출력" value={example.output} />

                    {example.explanation && (
                        <p className="border-t border-slate-100 p-4 text-sm leading-7 text-slate-500">
                            {example.explanation}
                        </p>
                    )}
                </Card>
            ))}
        </div>
    );
}

function ProblemHints({ problem }: { problem: ProblemDetail }) {
    return (
        <div className="space-y-3">
            {problem.hints.map((hint, index) => (
                <div
                    key={hint}
                    className="flex gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-bold leading-6 text-slate-600"
                >
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-xl bg-white text-xs font-black text-blue-600">
                        {index + 1}
                    </span>
                    {hint}
                </div>
            ))}
        </div>
    );
}

function ExampleBlock({ title, value }: { title: string; value: string }) {
    return (
        <div className="border-b border-slate-100 p-4 last:border-b-0">
            <div className="mb-2 flex items-center justify-between">
                <h4 className="text-sm font-black text-slate-950">{title}</h4>
                <Badge>{title === "입력" ? "stdin" : "stdout"}</Badge>
            </div>

            <pre className="overflow-x-auto rounded-2xl bg-slate-950 p-4 text-sm leading-7 text-slate-100">
                <code>{value}</code>
            </pre>
        </div>
    );
}

function EditorPanel({
                         language,
                         onLanguageChange,
                         code,
                         onCodeChange,
                         onCopy,
                         onReset,
                         onSave
                     }: {
    language: Language;
    onLanguageChange: (language: Language) => void;
    code: string;
    onCodeChange: (code: string) => void;
    onCopy: () => void;
    onReset: () => void;
    onSave: () => void;
}) {
    const codeLines = code.split("\n").length;
    const languageInfo = languageSettings[language];

    return (
        <Card className="relative z-10 flex min-h-[calc(100vh-190px)] flex-col overflow-visible">
            <div className="flex flex-col gap-3 rounded-t-3xl border-b border-slate-100 bg-white p-3 xl:flex-row xl:items-end xl:justify-between">
                <div className="grid gap-3 sm:grid-cols-[220px_1fr] xl:flex xl:items-end">
                    <FilterSelect
                        label="언어"
                        value={language}
                        onChange={onLanguageChange}
                        options={LANGUAGE_OPTIONS}
                    />

                    <div className="flex flex-wrap gap-2 xl:pb-0.5">
                        <Badge variant="blue">Main.{languageInfo.ext}</Badge>
                        <Badge>
                            {languageInfo.compile === "-" ? "인터프리터" : languageInfo.compile}
                        </Badge>
                        <Badge>{languageInfo.run}</Badge>
                        <Badge>{codeLines} lines</Badge>
                    </div>
                </div>

                <div className="flex flex-wrap gap-2">
                    <AppButton variant="secondary" icon={Copy} onClick={onCopy}>
                        복사
                    </AppButton>

                    <AppButton variant="secondary" icon={RotateCcw} onClick={onReset}>
                        초기화
                    </AppButton>

                    <AppButton variant="secondary" icon={Save} onClick={onSave}>
                        저장
                    </AppButton>
                </div>
            </div>

            <div className="relative flex-1 overflow-visible rounded-b-3xl bg-slate-950">
                <JudgeMonacoEditor
                    key={language}
                    height="calc(100vh - 285px)"
                    theme="vs-dark"
                    language={monacoLanguageMap[language]}
                    judgeLanguage={language}
                    fileName={`Main.${languageInfo.ext}`}
                    value={code}
                    onChange={onCodeChange}
                    options={{
                        minimap: {
                            enabled: true
                        },
                        fixedOverflowWidgets: true
                    }}
                />
            </div>
        </Card>
    );
}

function ConsolePanel({
                          activeTab,
                          onTabChange,
                          customInput,
                          onCustomInputChange,
                          runStatus,
                          results,
                          language,
                          problem,
                          onRun,
                          onSubmit
                      }: {
    activeTab: ConsoleTab;
    onTabChange: (tab: ConsoleTab) => void;
    customInput: string;
    onCustomInputChange: (value: string) => void;
    runStatus: RunStatus;
    results: JudgeResult[];
    language: Language;
    problem: ProblemDetail;
    onRun: () => void;
    onSubmit: () => void;
}) {
    const notice = getRunStatusNotice(runStatus);
    const languageInfo = languageSettings[language];

    return (
        <Card className="flex min-h-[calc(100vh-190px)] flex-col overflow-hidden">
            <div className="border-b border-slate-100 bg-white p-3">
                <div className="grid grid-cols-3 gap-2">
                    {(["result", "custom", "settings"] as ConsoleTab[]).map((tab) => (
                        <button
                            key={tab}
                            type="button"
                            onClick={() => onTabChange(tab)}
                            className={`rounded-2xl px-3 py-2.5 text-sm font-black transition ${
                                activeTab === tab
                                    ? "bg-slate-950 text-white"
                                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-950"
                            }`}
                        >
                            {consoleTabLabels[tab]}
                        </button>
                    ))}
                </div>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto p-5">
                {activeTab === "result" && (
                    <>
                        <Notice variant={notice.variant} title="실행 상태">
                            {notice.message}
                        </Notice>
                        <ResultList results={results} />
                    </>
                )}

                {activeTab === "custom" && (
                    <div className="space-y-4">
                        <div>
                            <h3 className="font-black text-slate-950">사용자 입력</h3>
                            <p className="mt-1 text-sm text-slate-500">
                                예제 외 직접 테스트할 입력을 작성합니다.
                            </p>
                        </div>

                        <textarea
                            value={customInput}
                            onChange={(event) => onCustomInputChange(event.target.value)}
                            className="min-h-64 w-full resize-y rounded-2xl border border-slate-200 bg-slate-50 p-4 font-mono text-sm leading-6 text-slate-800 outline-none ring-blue-100 transition focus:border-blue-300 focus:bg-white focus:ring-4"
                            placeholder="사용자 입력을 작성하세요."
                        />

                        <AppButton
                            variant="primary"
                            icon={Play}
                            onClick={onRun}
                            disabled={runStatus === "running"}
                        >
                            사용자 입력 실행
                        </AppButton>
                    </div>
                )}

                {activeTab === "settings" && (
                    <div className="space-y-3">
                        <SettingRow label="언어" value={language} />
                        <SettingRow label="파일" value={`Main.${languageInfo.ext}`} />
                        <SettingRow label="컴파일" value={languageInfo.compile} />
                        <SettingRow label="실행" value={languageInfo.run} />
                        <SettingRow label="시간 제한" value={problem.timeLimit} />
                        <SettingRow label="메모리 제한" value={problem.memoryLimit} />
                    </div>
                )}
            </div>

            <div className="border-t border-slate-100 bg-white p-4">
                <div className="grid grid-cols-2 gap-3">
                    <AppButton
                        variant="secondary"
                        icon={Play}
                        onClick={onRun}
                        disabled={runStatus === "running"}
                    >
                        실행
                    </AppButton>

                    <AppButton
                        variant="primary"
                        icon={Send}
                        onClick={onSubmit}
                        disabled={runStatus === "running"}
                    >
                        제출
                    </AppButton>
                </div>
            </div>
        </Card>
    );
}

function ResultList({ results }: { results: JudgeResult[] }) {
    if (results.length === 0) {
        return (
            <Card className="p-5">
                <div className="flex items-center gap-3 text-sm font-bold text-slate-500">
                    <Terminal className="h-5 w-5" />
                    실행 결과가 여기에 표시됩니다.
                </div>
            </Card>
        );
    }

    return (
        <div className="space-y-3">
            {results.map((result) => (
                <Card key={result.id} className="p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                            <SubmissionStatusBadge value={result.status} />
                            <span className="text-sm font-black text-slate-800">
                                {result.label}
                            </span>
                        </div>

                        <div className="flex gap-2 text-xs font-bold text-slate-400">
                            <span>{result.time}</span>
                            <span>{result.memory}</span>
                        </div>
                    </div>

                    <p className="mt-3 text-sm leading-6 text-slate-500">
                        {result.message}
                    </p>
                </Card>
            ))}
        </div>
    );
}

function SettingRow({ label, value }: { label: string; value: string }) {
    return (
        <div className="flex items-start justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-bold">
            <span className="shrink-0 text-slate-400">{label}</span>
            <span className="break-all text-right text-slate-700">{value}</span>
        </div>
    );
}

function QuickLink({
                       href,
                       label,
                       icon: Icon
                   }: {
    href: string;
    label: string;
    icon: ComponentType<{ className?: string }>;
}) {
    return (
        <Link
            href={href}
            className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-blue-50 hover:text-blue-700"
        >
            <span className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                {label}
            </span>
            <ChevronRight className="h-4 w-4" />
        </Link>
    );
}

function CompactInfoPanel({
                              problem,
                              codeBytes
                          }: {
    problem: ProblemDetail;
    codeBytes: number;
}) {
    return (
        <div className="grid gap-4 xl:grid-cols-4">
            <Card className="p-4">
                <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-600 text-white">
                        <Trophy className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-xs font-bold text-slate-400">정답률</p>
                        <p className="text-lg font-black text-slate-950">
                            {problem.solvedRate}%
                        </p>
                    </div>
                </div>
            </Card>

            <Card className="p-4">
                <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-600 text-white">
                        <Timer className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-xs font-bold text-slate-400">시간 제한</p>
                        <p className="text-lg font-black text-slate-950">
                            {problem.timeLimit}
                        </p>
                    </div>
                </div>
            </Card>

            <Card className="p-4">
                <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-orange-500 text-white">
                        <MemoryStick className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-xs font-bold text-slate-400">메모리</p>
                        <p className="text-lg font-black text-slate-950">
                            {problem.memoryLimit}
                        </p>
                    </div>
                </div>
            </Card>

            <Card className="p-4">
                <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-white">
                        <FileCode2 className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-xs font-bold text-slate-400">코드 크기</p>
                        <p className="text-lg font-black text-slate-950">
                            {codeBytes.toLocaleString()}B
                        </p>
                    </div>
                </div>
            </Card>
        </div>
    );
}

export default function ProblemSolvePage() {
    const params = useParams<{ id: string }>();
    const id = String(params.id ?? "");
    const problemId = Number(id);
    const problem = Number.isFinite(problemId) ? findProblem(problemId) : undefined;

    const [language, setLanguage] = useState<Language>("C++17");
    const [code, setCode] = useState(DEFAULT_CODE["C++17"]);
    const [customInput, setCustomInput] = useState("");
    const [runStatus, setRunStatus] = useState<RunStatus>("idle");
    const [results, setResults] = useState<JudgeResult[]>([]);
    const [message, setMessage] = useState<string | null>(null);
    const [problemTab, setProblemTab] = useState<ProblemTab>("description");
    const [consoleTab, setConsoleTab] = useState<ConsoleTab>("result");

    const codeBytes = useMemo(() => new Blob([code]).size, [code]);

    if (!problem) {
        return <NotFoundProblem id={id} />;
    }

    const showMessage = (text: string) => {
        setMessage(text);
        window.setTimeout(() => setMessage(null), 1800);
    };

    const handleLanguageChange = (nextLanguage: Language) => {
        setLanguage(nextLanguage);
        setCode(DEFAULT_CODE[nextLanguage]);
        setRunStatus("idle");
        setResults([]);
    };

    const runJudge = async (isSubmit: boolean) => {
        setRunStatus("running");
        setConsoleTab("result");
        setResults([
            {
                id: "judging",
                label: isSubmit ? "제출" : "실행",
                status: "judging",
                time: "-",
                memory: "-",
                message: "채점 서버에서 코드를 실행하고 있습니다."
            }
        ]);

        try {
            const data = await requestJudgeApi({
                mode: isSubmit ? "submit" : "run",
                problem,
                language,
                code,
                customInput
            });

            const nextStatus = toRunStatus(data.status);

            setRunStatus(nextStatus);
            setResults(convertJudgeResults(data.results));

            if (isSubmit) {
                showMessage(
                    data.status === "accepted"
                        ? "제출 완료: 맞았습니다."
                        : data.message ?? "제출 완료: 결과를 확인하세요."
                );
            } else {
                showMessage(
                    data.status === "accepted"
                        ? "실행 완료: 통과했습니다."
                        : data.message ?? "실행 완료: 결과를 확인하세요."
                );
            }
        } catch (error) {
            const errorMessage =
                error instanceof Error
                    ? error.message
                    : "채점 중 알 수 없는 오류가 발생했습니다.";

            setRunStatus("compile");
            setResults([
                {
                    id: "judge-error",
                    label: "채점 서버",
                    status: "runtime",
                    time: "-",
                    memory: "-",
                    message: errorMessage
                }
            ]);

            showMessage("채점 서버 오류가 발생했습니다.");
        }
    };

    const handleResetCode = () => {
        setCode(DEFAULT_CODE[language]);
        setRunStatus("idle");
        setResults([]);
        showMessage("기본 코드로 초기화했습니다.");
    };

    const handleUseSampleInput = (input: string) => {
        setCustomInput(input);
        setConsoleTab("custom");
        showMessage("예제 입력을 사용자 입력에 복사했습니다.");
    };

    const handleCopyCode = async () => {
        await navigator.clipboard.writeText(code);
        showMessage("코드를 클립보드에 복사했습니다.");
    };

    return (
        <AppShell
            title="코딩 테스트"
            description={`${problem.id}. ${problem.title}`}
            fullWidth
            contentClassName="py-4"
        >
            <div className="space-y-4">
                <ExamTopBar
                    problem={problem}
                    language={language}
                    runStatus={runStatus}
                    onRun={() => void runJudge(false)}
                    onSubmit={() => void runJudge(true)}
                />

                {message && (
                    <Notice variant="success" title="알림">
                        {message}
                    </Notice>
                )}

                <CompactInfoPanel problem={problem} codeBytes={codeBytes} />

                <section className="grid gap-4 2xl:grid-cols-[390px_minmax(0,1fr)_390px]">
                    <ProblemPanel
                        problem={problem}
                        activeTab={problemTab}
                        onTabChange={setProblemTab}
                        onUseSample={handleUseSampleInput}
                    />

                    <EditorPanel
                        language={language}
                        onLanguageChange={handleLanguageChange}
                        code={code}
                        onCodeChange={setCode}
                        onCopy={handleCopyCode}
                        onReset={handleResetCode}
                        onSave={() => showMessage("임시 저장했습니다.")}
                    />

                    <ConsolePanel
                        activeTab={consoleTab}
                        onTabChange={setConsoleTab}
                        customInput={customInput}
                        onCustomInputChange={setCustomInput}
                        runStatus={runStatus}
                        results={results}
                        language={language}
                        problem={problem}
                        onRun={() => void runJudge(false)}
                        onSubmit={() => void runJudge(true)}
                    />
                </section>

                <section className="grid gap-4 lg:grid-cols-[1fr_360px]">
                    <Card className="p-5">
                        <div className="mb-3 flex items-center gap-2 font-black text-slate-950">
                            <ShieldCheck className="h-5 w-5 text-blue-600" />
                            코딩테스트 모드 안내
                        </div>

                        <p className="text-sm leading-7 text-slate-500">
                            이 화면은 실제 코딩테스트처럼 문제, 에디터, 실행 결과를 한 화면에서 볼 수 있게 구성했습니다.
                            실행과 제출 버튼은 `/api/judge` 채점 API로 코드를 전송합니다.
                        </p>
                    </Card>

                    <SidePanel title="빠른 이동" badge={<History className="h-5 w-5 text-blue-600" />}>
                        <div className="space-y-2">
                            <QuickLink
                                href={`/problems/${problem.id}`}
                                label="문제 상세"
                                icon={BookOpen}
                            />
                            <QuickLink
                                href={`/problems/${problem.id}/submissions`}
                                label="이 문제 제출 기록"
                                icon={ListChecks}
                            />
                            <QuickLink href="/notes" label="오답노트" icon={NotebookPen} />
                        </div>
                    </SidePanel>
                </section>
            </div>
        </AppShell>
    );
}