"use client";

import AppShell from "@/components/layout/AppShell";
import {
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    PageHero,
    StatCard
} from "@/components/ui";
import {
    FilterPanel,
    FilterSelect,
    SearchInput
} from "@/components/forms";
import {
    ListHeader,
    ViewModeToggle,
    type ViewMode
} from "@/components/common";
import {
    DifficultyBadge,
    ProblemCard,
    ProblemStatusBadge,
    ProblemTable,
    type Difficulty,
    type ProblemCardData,
    type ProblemStatus
} from "@/components/domain";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import {
    ArrowRight,
    BookOpen,
    CheckCircle2,
    Clock3,
    Database,
    Hash,
    Search,
    Sparkles,
    Target,
    Trophy
} from "lucide-react";

type ProblemCategory =
    | "전체"
    | "구현"
    | "자료구조"
    | "그래프"
    | "DP"
    | "문자열"
    | "수학";

type DifficultyFilter = "전체" | Difficulty;
type StatusFilter = "전체" | "해결" | "오답" | "미해결" | "복습";

type SortOption =
    | "recommended"
    | "number-asc"
    | "number-desc"
    | "difficulty"
    | "solved-rate"
    | "score-desc";

type Problem = ProblemCardData & {
    category: Exclude<ProblemCategory, "전체">;
    source: string;
};

const PROBLEMS: Problem[] = [
    {
        id: 1000,
        title: "두 수의 합",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "solved",
        solvedRate: 69.5,
        submissions: 184,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["implementation", "math", "입출력"],
        memo: "기본 입출력과 사칙연산을 확인하는 입문 문제입니다.",
        recommendedOrder: 1,
        source: "local"
    },
    {
        id: 10871,
        title: "X보다 작은 수",
        difficulty: "Easy",
        category: "구현",
        score: 100,
        status: "todo",
        solvedRate: 62.1,
        submissions: 151,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["implementation", "array", "반복문"],
        memo: "배열 순회와 조건 출력 연습에 적합합니다.",
        recommendedOrder: 2,
        source: "local"
    },
    {
        id: 2675,
        title: "문자열 반복",
        difficulty: "Easy",
        category: "문자열",
        score: 100,
        status: "solved",
        solvedRate: 66.2,
        submissions: 128,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["string", "implementation"],
        memo: "문자 단위 반복 출력 문제입니다.",
        recommendedOrder: 3,
        source: "local"
    },
    {
        id: 10828,
        title: "스택 명령 처리",
        difficulty: "Medium",
        category: "자료구조",
        score: 150,
        status: "solved",
        solvedRate: 60.5,
        submissions: 119,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["stack", "data-structure", "자료구조"],
        memo: "스택 명령 처리와 입출력 최적화를 연습합니다.",
        recommendedOrder: 4,
        source: "local"
    },
    {
        id: 9012,
        title: "괄호",
        difficulty: "Medium",
        category: "자료구조",
        score: 130,
        status: "review",
        solvedRate: 54.2,
        submissions: 132,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["stack", "string"],
        memo: "닫는 괄호가 나왔을 때 빈 스택이면 실패입니다.",
        recommendedOrder: 5,
        source: "local"
    },
    {
        id: 10845,
        title: "큐",
        difficulty: "Medium",
        category: "자료구조",
        score: 140,
        status: "todo",
        solvedRate: 56.7,
        submissions: 88,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["queue", "data-structure"],
        memo: "큐 명령 처리 패턴은 스택 문제와 유사합니다.",
        recommendedOrder: 6,
        source: "local"
    },
    {
        id: 2178,
        title: "미로 탐색",
        difficulty: "Medium",
        category: "그래프",
        score: 150,
        status: "todo",
        solvedRate: 44.7,
        submissions: 115,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "graph", "grid"],
        memo: "격자 BFS의 기본 문제입니다.",
        recommendedOrder: 7,
        source: "local"
    },
    {
        id: 7576,
        title: "토마토",
        difficulty: "Medium",
        category: "그래프",
        score: 180,
        status: "wrong",
        solvedRate: 45.8,
        submissions: 96,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["bfs", "queue", "graph"],
        memo: "다중 시작점 BFS입니다. 모든 익은 토마토를 큐에 넣어야 합니다.",
        recommendedOrder: 8,
        source: "local"
    },
    {
        id: 1260,
        title: "DFS와 BFS",
        difficulty: "Medium",
        category: "그래프",
        score: 150,
        status: "todo",
        solvedRate: 50.1,
        submissions: 142,
        timeLimit: "2초",
        memoryLimit: "256MB",
        tags: ["dfs", "bfs", "graph"],
        memo: "방문 순서를 맞추려면 인접 리스트 정렬이 필요합니다.",
        recommendedOrder: 9,
        source: "local"
    },
    {
        id: 1463,
        title: "1로 만들기",
        difficulty: "Medium",
        category: "DP",
        score: 140,
        status: "todo",
        solvedRate: 49.5,
        submissions: 178,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["dp", "dynamic-programming"],
        memo: "dp[i]를 i를 1로 만드는 최소 연산 수로 정의합니다.",
        recommendedOrder: 10,
        source: "local"
    },
    {
        id: 11053,
        title: "가장 긴 증가하는 부분 수열",
        difficulty: "Medium",
        category: "DP",
        score: 150,
        status: "solved",
        solvedRate: 63.3,
        submissions: 101,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["dp", "lis", "binary-search"],
        memo: "O(N²) DP와 O(N log N) 풀이를 모두 연습할 수 있습니다.",
        recommendedOrder: 11,
        source: "local"
    },
    {
        id: 12865,
        title: "평범한 배낭",
        difficulty: "Hard",
        category: "DP",
        score: 200,
        status: "wrong",
        solvedRate: 38.1,
        submissions: 76,
        timeLimit: "2초",
        memoryLimit: "512MB",
        tags: ["dp", "knapsack"],
        memo: "1차원 DP는 무게를 뒤에서 앞으로 갱신해야 합니다.",
        recommendedOrder: 12,
        source: "local"
    },
    {
        id: 2609,
        title: "최대공약수와 최소공배수",
        difficulty: "Easy",
        category: "수학",
        score: 100,
        status: "todo",
        solvedRate: 57.4,
        submissions: 112,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["math", "number-theory"],
        memo: "유클리드 호제법을 사용합니다.",
        recommendedOrder: 13,
        source: "local"
    },
    {
        id: 1753,
        title: "최단경로",
        difficulty: "Hard",
        category: "그래프",
        score: 220,
        status: "todo",
        solvedRate: 29.4,
        submissions: 72,
        timeLimit: "1초",
        memoryLimit: "512MB",
        tags: ["dijkstra", "graph", "shortest-path"],
        memo: "우선순위 큐와 인접 리스트를 사용합니다.",
        recommendedOrder: 14,
        source: "local"
    },
    {
        id: 2805,
        title: "나무 자르기",
        difficulty: "Medium",
        category: "자료구조",
        score: 170,
        status: "todo",
        solvedRate: 37.2,
        submissions: 88,
        timeLimit: "1초",
        memoryLimit: "256MB",
        tags: ["binary-search", "parametric-search"],
        memo: "답의 범위를 이분 탐색하는 매개 변수 탐색 문제입니다.",
        recommendedOrder: 15,
        source: "local"
    }
];

const CATEGORY_OPTIONS: readonly ProblemCategory[] = [
    "전체",
    "구현",
    "자료구조",
    "그래프",
    "DP",
    "문자열",
    "수학"
];

const DIFFICULTY_OPTIONS: readonly DifficultyFilter[] = [
    "전체",
    "Easy",
    "Medium",
    "Hard"
];

const STATUS_OPTIONS: readonly StatusFilter[] = [
    "전체",
    "해결",
    "오답",
    "미해결",
    "복습"
];

const SORT_OPTIONS: readonly SortOption[] = [
    "recommended",
    "number-asc",
    "number-desc",
    "difficulty",
    "solved-rate",
    "score-desc"
];

const statusLabelToValue: Record<Exclude<StatusFilter, "전체">, ProblemStatus> = {
    해결: "solved",
    오답: "wrong",
    미해결: "todo",
    복습: "review"
};

const difficultyOrder: Record<Difficulty, number> = {
    Easy: 1,
    Medium: 2,
    Hard: 3
};

const sortLabels: Record<SortOption, string> = {
    recommended: "추천순",
    "number-asc": "번호 낮은순",
    "number-desc": "번호 높은순",
    difficulty: "난이도순",
    "solved-rate": "정답률 높은순",
    "score-desc": "점수 높은순"
};

function normalizeKeyword(value: string) {
    return value.trim().toLowerCase();
}

function matchesTag(problem: Problem, tag: string) {
    if (!tag) {
        return true;
    }

    return problem.tags?.some((item) => item.toLowerCase() === tag.toLowerCase()) ?? false;
}

export default function ProblemsPage() {
    const searchParams = useSearchParams();
    const queryTag = searchParams.get("tag") ?? "";

    const [keyword, setKeyword] = useState("");
    const [category, setCategory] = useState<ProblemCategory>("전체");
    const [difficulty, setDifficulty] = useState<DifficultyFilter>("전체");
    const [status, setStatus] = useState<StatusFilter>("전체");
    const [sort, setSort] = useState<SortOption>("recommended");
    const [viewMode, setViewMode] = useState<ViewMode>("card");

    const filteredProblems = useMemo(() => {
        const lowerKeyword = normalizeKeyword(keyword);

        const result = PROBLEMS.filter((problem) => {
            const matchesKeyword =
                !lowerKeyword ||
                String(problem.id).includes(lowerKeyword) ||
                problem.title.toLowerCase().includes(lowerKeyword) ||
                problem.category.toLowerCase().includes(lowerKeyword) ||
                problem.memo?.toLowerCase().includes(lowerKeyword) ||
                problem.tags?.some((tag) => tag.toLowerCase().includes(lowerKeyword));

            const matchesCategory = category === "전체" || problem.category === category;
            const matchesDifficulty = difficulty === "전체" || problem.difficulty === difficulty;
            const matchesStatus = status === "전체" || problem.status === statusLabelToValue[status];
            const matchesQueryTag = matchesTag(problem, queryTag);

            return (
                matchesKeyword &&
                matchesCategory &&
                matchesDifficulty &&
                matchesStatus &&
                matchesQueryTag
            );
        });

        return result.sort((a, b) => {
            switch (sort) {
                case "number-asc":
                    return a.id - b.id;

                case "number-desc":
                    return b.id - a.id;

                case "difficulty":
                    return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];

                case "solved-rate":
                    return (b.solvedRate ?? 0) - (a.solvedRate ?? 0);

                case "score-desc":
                    return (b.score ?? 0) - (a.score ?? 0);

                case "recommended":
                default:
                    return (a.recommendedOrder ?? 9999) - (b.recommendedOrder ?? 9999);
            }
        });
    }, [keyword, category, difficulty, status, sort, queryTag]);

    const solvedCount = PROBLEMS.filter((problem) => problem.status === "solved").length;
    const wrongCount = PROBLEMS.filter((problem) => problem.status === "wrong").length;
    const reviewCount = PROBLEMS.filter((problem) => problem.status === "review").length;
    const hardCount = PROBLEMS.filter((problem) => problem.difficulty === "Hard").length;

    const averageSolvedRate =
        Math.round(
            (PROBLEMS.reduce((sum, problem) => sum + (problem.solvedRate ?? 0), 0) /
                PROBLEMS.length) *
            10
        ) / 10;

    const tagCount = Array.from(
        new Set(PROBLEMS.flatMap((problem) => problem.tags ?? []))
    ).length;

    const resetFilters = () => {
        setKeyword("");
        setCategory("전체");
        setDifficulty("전체");
        setStatus("전체");
        setSort("recommended");
    };

    return (
        <AppShell
            title="문제 검색"
            description="로컬에 저장된 문제를 검색하고 풀이할 수 있습니다."
        >
            <div className="space-y-6">
                <PageHero
                    eyebrow={
                        <>
                            <Badge variant="blue">Problems</Badge>
                            <Badge>Local Dataset</Badge>
                            {queryTag && <Badge variant="green">#{queryTag}</Badge>}
                        </>
                    }
                    title="문제를 찾고, 바로 풀이를 시작하세요."
                    description="번호, 제목, 태그, 분류, 난이도, 풀이 상태를 기준으로 문제를 빠르게 찾을 수 있습니다. 태그 상세 페이지에서 넘어온 경우 해당 태그 문제만 먼저 보여줍니다."
                    icon={BookOpen}
                    rightTitle="검색 대상 문제"
                    rightValue={PROBLEMS.length.toLocaleString()}
                    rightCaption={`평균 정답률 ${averageSolvedRate}%`}
                    metrics={[
                        { label: "해결", value: `${solvedCount}` },
                        { label: "오답", value: `${wrongCount}` },
                        { label: "Hard", value: `${hardCount}` }
                    ]}
                    actions={
                        <>
                            <AppLinkButton
                                href="/problems/1000/solve"
                                variant="primary"
                                size="lg"
                                iconRight={ArrowRight}
                            >
                                추천 문제 풀기
                            </AppLinkButton>

                            <AppLinkButton href="/sets" variant="white" size="lg">
                                문제 세트 보기
                            </AppLinkButton>
                        </>
                    }
                />

                <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <StatCard
                        label="전체 문제"
                        value={PROBLEMS.length.toLocaleString()}
                        caption="샘플 로컬 문제"
                        icon={Database}
                    />

                    <StatCard
                        label="해결 문제"
                        value={solvedCount.toLocaleString()}
                        caption="현재 사용자 기준"
                        icon={CheckCircle2}
                        tone="green"
                    />

                    <StatCard
                        label="복습 필요"
                        value={(wrongCount + reviewCount).toLocaleString()}
                        caption="오답 또는 복습 상태"
                        icon={Clock3}
                        tone="orange"
                    />

                    <StatCard
                        label="태그 수"
                        value={tagCount.toLocaleString()}
                        caption="문제 분류 태그"
                        icon={Hash}
                        tone="blue"
                    />
                </section>

                <FilterPanel
                    title="문제 검색 / 필터"
                    onReset={resetFilters}
                    gridClassName="grid gap-3 xl:grid-cols-[1.4fr_150px_150px_150px_180px_auto] xl:items-end"
                >
                    <SearchInput
                        value={keyword}
                        onChange={setKeyword}
                        placeholder="문제 번호, 제목, 태그, 메모 검색"
                    />

                    <FilterSelect
                        label="분류"
                        value={category}
                        onChange={setCategory}
                        options={CATEGORY_OPTIONS}
                    />

                    <FilterSelect
                        label="난이도"
                        value={difficulty}
                        onChange={setDifficulty}
                        options={DIFFICULTY_OPTIONS}
                    />

                    <FilterSelect
                        label="상태"
                        value={status}
                        onChange={setStatus}
                        options={STATUS_OPTIONS}
                    />

                    <FilterSelect
                        label="정렬"
                        value={sort}
                        onChange={setSort}
                        options={SORT_OPTIONS}
                    />
                </FilterPanel>

                <section>
                    <ListHeader
                        title="문제 목록"
                        description={`검색 조건에 맞는 문제 ${filteredProblems.length.toLocaleString()}개가 표시됩니다. 현재 정렬: ${sortLabels[sort]}`}
                        right={<ViewModeToggle value={viewMode} onChange={setViewMode} />}
                    />

                    {filteredProblems.length === 0 ? (
                        <EmptyState
                            title="문제를 찾을 수 없습니다."
                            description="검색어, 필터 또는 태그 조건을 변경해보세요."
                            icon={Search}
                            onReset={resetFilters}
                        />
                    ) : viewMode === "card" ? (
                        <div className="grid gap-4 xl:grid-cols-2">
                            {filteredProblems.map((problem) => (
                                <ProblemCard key={problem.id} problem={problem} />
                            ))}
                        </div>
                    ) : (
                        <ProblemTable problems={filteredProblems} />
                    )}
                </section>

                <section className="grid gap-4 lg:grid-cols-3">
                    <Card className="p-5">
                        <div className="mb-3 flex items-center gap-2 font-black text-slate-950">
                            <Sparkles className="h-5 w-5 text-blue-600" />
                            추천 흐름
                        </div>
                        <p className="text-sm leading-7 text-slate-500">
                            처음에는 Easy 구현 문제를 풀고, 이후 스택/큐, BFS, DP 순서로 확장하는 흐름이 좋습니다.
                        </p>
                    </Card>

                    <Card className="p-5">
                        <div className="mb-3 flex items-center gap-2 font-black text-slate-950">
                            <Target className="h-5 w-5 text-blue-600" />
                            오늘 목표
                        </div>
                        <p className="text-sm leading-7 text-slate-500">
                            현재 샘플 기준으로 미해결 Medium 문제 2개와 오답 문제 1개를 우선 추천합니다.
                        </p>
                    </Card>

                    <Card className="p-5">
                        <div className="mb-3 flex items-center gap-2 font-black text-slate-950">
                            <Trophy className="h-5 w-5 text-blue-600" />
                            실전 대비
                        </div>
                        <p className="text-sm leading-7 text-slate-500">
                            문제 검색에 익숙해지면 `/tests`에서 제한 시간 기반 모의 테스트를 진행하면 됩니다.
                        </p>
                    </Card>
                </section>
            </div>
        </AppShell>
    );
}