import { NextRequest, NextResponse } from "next/server";
import { spawn } from "child_process";
import { mkdir, rm, writeFile } from "fs/promises";
import os from "os";
import path from "path";
import { randomUUID } from "crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type JudgeMode = "run" | "submit";

type Language =
    | "C++17"
    | "Python 3.12"
    | "Java 17"
    | "JavaScript"
    | "Dart"
    | "C# 12";

type JudgeStatus =
    | "accepted"
    | "wrong"
    | "compile"
    | "runtime"
    | "timeLimit"
    | "memoryLimit"
    | "pending"
    | "judging";

type JudgeRequestTest = {
    id?: string;
    label?: string;
    input: string;
    expectedOutput?: string;
};

type JudgeRequest = {
    mode: JudgeMode;
    problemId: number;
    problemTitle: string;
    language: Language;
    sourceFile: string;
    code: string;
    tests: JudgeRequestTest[];
    timeLimit: string;
    memoryLimit: string;
};

type JudgeCaseResult = {
    id: string;
    label: string;
    status: JudgeStatus;
    timeMs?: number;
    memoryKb?: number;
    message: string;
    input?: string;
    expectedOutput?: string;
    actualOutput?: string;
};

type LanguageConfig = {
    image: string;
    sourceFile: string;
    prepareFiles?: (workspace: string, code: string) => Promise<void>;
    compileCommand?: string;
    runCommand: string;
    minMemoryMb?: number;
};

type CommandResult = {
    exitCode: number | null;
    stdout: string;
    stderr: string;
    timeMs: number;
    timedOut: boolean;
};

const MAX_OUTPUT_LENGTH = 200_000;

function shellQuote(value: string) {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}

function normalizeOutput(value: string) {
    return value.replace(/\r\n/g, "\n").trimEnd();
}

function parseTimeLimitMs(value: string) {
    const number = Number(value.match(/[\d.]+/)?.[0] ?? "2");

    if (!Number.isFinite(number) || number <= 0) {
        return 2000;
    }

    if (value.toLowerCase().includes("ms")) {
        return Math.max(500, Math.min(number, 10_000));
    }

    return Math.max(500, Math.min(number * 1000, 10_000));
}

function parseMemoryLimitMb(value: string) {
    const number = Number(value.match(/[\d.]+/)?.[0] ?? "256");

    if (!Number.isFinite(number) || number <= 0) {
        return 256;
    }

    if (value.toLowerCase().includes("gb")) {
        return Math.max(128, Math.min(number * 1024, 2048));
    }

    return Math.max(128, Math.min(number, 2048));
}

function toSafeFileName(fileName: string, fallback: string) {
    const baseName = path.basename(fileName || fallback);

    if (!baseName || baseName === "." || baseName === "..") {
        return fallback;
    }

    return baseName;
}

function getLanguageConfig(language: Language, sourceFile: string): LanguageConfig {
    switch (language) {
        case "C++17": {
            const file = toSafeFileName(sourceFile, "Main.cpp");

            return {
                image: "gcc:13-bookworm",
                sourceFile: file,
                compileCommand: `g++ -std=c++17 -O2 -pipe -Wall -Wextra -o /work/main /work/${shellQuote(file)}`,
                runCommand: "/work/main",
                minMemoryMb: 256
            };
        }

        case "Python 3.12": {
            const file = toSafeFileName(sourceFile, "Main.py");

            return {
                image: "python:3.12",
                sourceFile: file,
                runCommand: `python3 /work/${shellQuote(file)}`,
                minMemoryMb: 128
            };
        }

        case "Java 17": {
            return {
                image: "eclipse-temurin:21-jdk",
                sourceFile: "Main.java",
                compileCommand: "javac /work/Main.java",
                runCommand: "java -cp /work Main",
                minMemoryMb: 256
            };
        }

        case "JavaScript": {
            const file = toSafeFileName(sourceFile, "Main.js");

            return {
                image: "node:22",
                sourceFile: file,
                compileCommand: `node --check /work/${shellQuote(file)}`,
                runCommand: `node /work/${shellQuote(file)}`,
                minMemoryMb: 128
            };
        }

        case "Dart": {
            const file = toSafeFileName(sourceFile, "Main.dart");

            return {
                image: "dart:stable",
                sourceFile: file,
                runCommand: `dart /work/${shellQuote(file)}`,
                minMemoryMb: 256
            };
        }

        case "C# 12": {
            return {
                image: "mcr.microsoft.com/dotnet/sdk:8.0",
                sourceFile: "Main.cs",
                prepareFiles: async (workspace) => {
                    await writeFile(
                        path.join(workspace, "JudgeWorkspace.csproj"),
                        [
                            '<Project Sdk="Microsoft.NET.Sdk">',
                            "  <PropertyGroup>",
                            "    <OutputType>Exe</OutputType>",
                            "    <TargetFramework>net8.0</TargetFramework>",
                            "    <LangVersion>12.0</LangVersion>",
                            "    <ImplicitUsings>enable</ImplicitUsings>",
                            "    <Nullable>enable</Nullable>",
                            "  </PropertyGroup>",
                            "</Project>",
                            ""
                        ].join("\n"),
                        "utf8"
                    );
                },
                compileCommand:
                    "dotnet build /work/JudgeWorkspace.csproj -c Release -o /work/out --nologo",
                runCommand: "dotnet /work/out/JudgeWorkspace.dll",
                minMemoryMb: 512
            };
        }

        default:
            throw new Error(`지원하지 않는 언어입니다: ${language}`);
    }
}

function appendLimited(current: string, chunk: Buffer) {
    if (current.length >= MAX_OUTPUT_LENGTH) {
        return current;
    }

    const next = current + chunk.toString("utf8");

    if (next.length > MAX_OUTPUT_LENGTH) {
        return next.slice(0, MAX_OUTPUT_LENGTH) + "\n... output truncated ...";
    }

    return next;
}

async function runDockerCommand({
                                    image,
                                    workspace,
                                    command,
                                    stdin,
                                    timeoutMs,
                                    memoryMb,
                                    phase
                                }: {
    image: string;
    workspace: string;
    command: string;
    stdin?: string;
    timeoutMs: number;
    memoryMb: number;
    phase: string;
}): Promise<CommandResult> {
    const containerName = `judge_${phase}_${randomUUID()}`;

    const args = [
        "run",
        "--rm",
        "--name",
        containerName,
        "--network",
        "none",
        "--cpus",
        "1",
        "--memory",
        `${memoryMb}m`,
        "--memory-swap",
        `${memoryMb}m`,
        "--pids-limit",
        "128",
        "--security-opt",
        "no-new-privileges",
        "--cap-drop",
        "ALL",
        "--tmpfs",
        "/tmp:rw,exec,nosuid,size=64m",
        "-i",
        "-v",
        `${workspace}:/work`,
        "--workdir",
        "/work",
        image,
        "sh",
        "-lc",
        command
    ];

    const startedAt = Date.now();

    return new Promise((resolve) => {
        let stdout = "";
        let stderr = "";
        let finished = false;
        let timedOut = false;

        const child = spawn("docker", args, {
            stdio: ["pipe", "pipe", "pipe"]
        });

        const timer = setTimeout(() => {
            timedOut = true;

            if (!finished) {
                child.kill("SIGKILL");

                const killer = spawn("docker", ["rm", "-f", containerName], {
                    stdio: "ignore"
                });

                killer.on("error", () => {});
            }
        }, timeoutMs);

        child.stdout.on("data", (chunk: Buffer) => {
            stdout = appendLimited(stdout, chunk);
        });

        child.stderr.on("data", (chunk: Buffer) => {
            stderr = appendLimited(stderr, chunk);
        });

        child.on("error", (error) => {
            clearTimeout(timer);
            finished = true;

            resolve({
                exitCode: -1,
                stdout,
                stderr: error.message,
                timeMs: Date.now() - startedAt,
                timedOut
            });
        });

        child.on("close", (exitCode) => {
            clearTimeout(timer);
            finished = true;

            resolve({
                exitCode,
                stdout,
                stderr,
                timeMs: Date.now() - startedAt,
                timedOut
            });
        });

        if (stdin !== undefined) {
            child.stdin.write(stdin);
        }

        child.stdin.end();
    });
}

function getFailureMessage(result: CommandResult) {
    const output = `${result.stderr}\n${result.stdout}`.trim();

    if (result.timedOut) {
        return "제한 시간을 초과했습니다.";
    }

    if (result.exitCode === 137) {
        return "메모리 제한을 초과했거나 컨테이너가 강제 종료되었습니다.";
    }

    return output || "실행 중 오류가 발생했습니다.";
}

function createCompileResult(message: string): JudgeCaseResult {
    return {
        id: "compile",
        label: "컴파일",
        status: "compile",
        timeMs: 0,
        memoryKb: 0,
        message
    };
}

function getOverallStatus(results: JudgeCaseResult[]): JudgeStatus {
    if (results.length === 0) {
        return "accepted";
    }

    if (results.some((result) => result.status === "compile")) {
        return "compile";
    }

    if (results.some((result) => result.status === "runtime")) {
        return "runtime";
    }

    if (results.some((result) => result.status === "timeLimit")) {
        return "timeLimit";
    }

    if (results.some((result) => result.status === "memoryLimit")) {
        return "memoryLimit";
    }

    if (results.some((result) => result.status === "wrong")) {
        return "wrong";
    }

    return "accepted";
}

async function prepareWorkspace(body: JudgeRequest, config: LanguageConfig) {
    const workspace = path.join(os.tmpdir(), `judge-${randomUUID()}`);

    await mkdir(workspace, {
        recursive: true
    });

    await writeFile(path.join(workspace, config.sourceFile), body.code, "utf8");

    if (config.prepareFiles) {
        await config.prepareFiles(workspace, body.code);
    }

    return workspace;
}

function validateRequest(body: Partial<JudgeRequest>) {
    if (!body) {
        return "요청 본문이 없습니다.";
    }

    if (body.mode !== "run" && body.mode !== "submit") {
        return "mode 값이 올바르지 않습니다.";
    }

    if (!body.language) {
        return "language 값이 없습니다.";
    }

    if (typeof body.code !== "string") {
        return "code 값이 없습니다.";
    }

    if (!Array.isArray(body.tests)) {
        return "tests 값이 없습니다.";
    }

    return null;
}

export async function POST(request: NextRequest) {
    let workspace: string | null = null;

    try {
        const body = (await request.json()) as JudgeRequest;
        const validationError = validateRequest(body);

        if (validationError) {
            return NextResponse.json(
                {
                    status: "compile",
                    message: validationError,
                    results: [createCompileResult(validationError)]
                },
                {
                    status: 400
                }
            );
        }

        const config = getLanguageConfig(body.language, body.sourceFile);
        const timeLimitMs = parseTimeLimitMs(body.timeLimit);
        const memoryLimitMb = Math.max(
            parseMemoryLimitMb(body.memoryLimit),
            config.minMemoryMb ?? 128
        );

        workspace = await prepareWorkspace(body, config);

        if (config.compileCommand) {
            const compileResult = await runDockerCommand({
                image: config.image,
                workspace,
                command: config.compileCommand,
                timeoutMs: Math.max(timeLimitMs, 8000),
                memoryMb: memoryLimitMb,
                phase: "compile"
            });

            if (compileResult.timedOut) {
                return NextResponse.json({
                    status: "compile",
                    message: "컴파일 시간이 초과되었습니다.",
                    results: [createCompileResult("컴파일 시간이 초과되었습니다.")]
                });
            }

            if (compileResult.exitCode !== 0) {
                const message = getFailureMessage(compileResult);

                return NextResponse.json({
                    status: "compile",
                    message,
                    results: [createCompileResult(message)]
                });
            }
        }

        const results: JudgeCaseResult[] = [];

        for (let index = 0; index < body.tests.length; index++) {
            const test = body.tests[index];
            const expectedOutput = test.expectedOutput ?? "";
            const hasExpectedOutput = expectedOutput.trim().length > 0;

            const runResult = await runDockerCommand({
                image: config.image,
                workspace,
                command: config.runCommand,
                stdin: test.input,
                timeoutMs: timeLimitMs + 1000,
                memoryMb: memoryLimitMb,
                phase: `run_${index + 1}`
            });

            let status: JudgeStatus = "accepted";
            let message = "정답입니다.";

            if (runResult.timedOut) {
                status = "timeLimit";
                message = "제한 시간을 초과했습니다.";
            } else if (runResult.exitCode === 137) {
                status = "memoryLimit";
                message = "메모리 제한을 초과했습니다.";
            } else if (runResult.exitCode !== 0) {
                status = "runtime";
                message = getFailureMessage(runResult);
            } else if (
                hasExpectedOutput &&
                normalizeOutput(runResult.stdout) !== normalizeOutput(expectedOutput)
            ) {
                status = "wrong";
                message = "출력이 정답과 다릅니다.";
            } else if (!hasExpectedOutput) {
                message = "사용자 입력 실행이 완료되었습니다.";
            }

            results.push({
                id: test.id ?? `case-${index + 1}`,
                label: test.label ?? `테스트 ${index + 1}`,
                status,
                timeMs: runResult.timeMs,
                memoryKb: undefined,
                message,
                input: test.input,
                expectedOutput,
                actualOutput: runResult.stdout
            });

            if (body.mode === "submit" && status !== "accepted") {
                break;
            }
        }

        const status = getOverallStatus(results);

        return NextResponse.json({
            status,
            message:
                status === "accepted"
                    ? body.mode === "submit"
                        ? "모든 테스트를 통과했습니다."
                        : "실행이 완료되었습니다."
                    : "일부 테스트가 실패했습니다.",
            results
        });
    } catch (error) {
        const message =
            error instanceof Error
                ? error.message
                : "채점 API 처리 중 알 수 없는 오류가 발생했습니다.";

        return NextResponse.json(
            {
                status: "runtime",
                message,
                results: [
                    {
                        id: "server-error",
                        label: "서버 오류",
                        status: "runtime",
                        timeMs: 0,
                        memoryKb: 0,
                        message
                    }
                ]
            },
            {
                status: 500
            }
        );
    } finally {
        if (workspace) {
            await rm(workspace, {
                recursive: true,
                force: true
            });
        }
    }
}