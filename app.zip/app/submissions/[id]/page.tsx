"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useMemo, useState } from "react";
import type { ComponentType } from "react";
import AppShell from "@/components/layout/AppShell";
import {
    AppButton,
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    MiniStat,
    Notice,
    PageHero,
    ProgressBar,
    SidePanel,
    StatCard
} from "@/components/ui";
import {
    SubmissionStatusBadge,
    type SubmissionStatus
} from "@/components/domain";
import JudgeMonacoEditor from "@/components/editor/JudgeMonacoEditor";
import {
    ArrowLeft,
    ArrowRight,
    BookOpen,
    CheckCircle2,
    ChevronRight,
    Clock3,
    Code2,
    Copy,
    FileCode2,
    Gauge,
    History,
    ListChecks,
    MemoryStick,
    NotebookPen,
    Play,
    Search,
    Sparkles,
    Terminal,
    Timer,
    UserRound,
    XCircle,
    Zap
} from "lucide-react";

type Language =
    | "C++17"
    | "Python 3.12"
    | "Java 17"
    | "JavaScript"
    | "Dart"
    | "C# 12";

const monacoLanguageMap: Record<Language, string> = {
    "C++17": "cpp",
    "Python 3.12": "python",
    "Java 17": "java",
    JavaScript: "javascript",
    Dart: "dart",
    "C# 12": "csharp"
};

type DetailTab = "overview" | "code" | "cases" | "log";

type CaseResult = {
    id: string;
    name: string;
    status: SubmissionStatus;
    input: string;
    expectedOutput: string;
    actualOutput: string;
    time: string;
    memory: string;
    message: string;
};

type SubmissionDetail = {
    id: number;
    problemId: number;
    problemTitle: string;
    status: SubmissionStatus;
    language: Language;
    user: string;
    timeMs: number | null;
    memoryKb: number | null;
    codeLength: number;
    submittedAt: string;
    submittedAtText: string;
    note: string;
    tags: string[];
    compileCommand: string;
    runCommand: string;
    sourceFile: string;
    code: string;
    compileLog: string;
    judgeLog: string[];
    cases: CaseResult[];
};

const submissions: SubmissionDetail[] = [
    {
        id: 202605030014,
        problemId: 7576,
        problemTitle: "토마토",
        status: "accepted",
        language: "C++17",
        user: "kimcode",
        timeMs: 20,
        memoryKb: 4020,
        codeLength: 1488,
        submittedAt: "2026-05-03T12:02:00",
        submittedAtText: "2026.05.03 12:02",
        note: "다중 시작점 BFS 수정 후 통과",
        tags: ["BFS", "Graph", "Queue"],
        compileCommand: "g++ -std=c++17 -O2 -pipe -static -s -o main main.cpp",
        runCommand: "./main",
        sourceFile: "main.cpp",
        code: `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int m, n;
    cin >> m >> n;

    vector<vector<int>> box(n, vector<int>(m));
    queue<pair<int, int>> q;

    for (int y = 0; y < n; y++) {
        for (int x = 0; x < m; x++) {
            cin >> box[y][x];
            if (box[y][x] == 1) {
                q.push({y, x});
            }
        }
    }

    int dy[4] = {-1, 1, 0, 0};
    int dx[4] = {0, 0, -1, 1};

    while (!q.empty()) {
        auto [y, x] = q.front();
        q.pop();

        for (int dir = 0; dir < 4; dir++) {
            int ny = y + dy[dir];
            int nx = x + dx[dir];

            if (ny < 0 || ny >= n || nx < 0 || nx >= m) continue;
            if (box[ny][nx] != 0) continue;

            box[ny][nx] = box[y][x] + 1;
            q.push({ny, nx});
        }
    }

    int answer = 0;
    for (int y = 0; y < n; y++) {
        for (int x = 0; x < m; x++) {
            if (box[y][x] == 0) {
                cout << -1 << '\\n';
                return 0;
            }
            answer = max(answer, box[y][x]);
        }
    }

    cout << answer - 1 << '\\n';
    return 0;
}
`,
        compileLog: "Compilation completed successfully.",
        judgeLog: [
            "[12:02:01] queued submission #202605030014",
            "[12:02:01] compile started: g++ -std=c++17 -O2",
            "[12:02:02] compile success",
            "[12:02:02] sample tests started",
            "[12:02:02] hidden tests started",
            "[12:02:03] all tests accepted"
        ],
        cases: [
            {
                id: "sample-1",
                name: "예제 1",
                status: "accepted",
                input: "6 4\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 0\n0 0 0 0 0 1",
                expectedOutput: "8",
                actualOutput: "8",
                time: "2ms",
                memory: "2024KB",
                message: "예제 출력과 일치합니다."
            },
            {
                id: "hidden-1",
                name: "Hidden 1",
                status: "accepted",
                input: "비공개",
                expectedOutput: "비공개",
                actualOutput: "비공개",
                time: "8ms",
                memory: "4020KB",
                message: "통과했습니다."
            },
            {
                id: "hidden-2",
                name: "Hidden 2",
                status: "accepted",
                input: "비공개",
                expectedOutput: "비공개",
                actualOutput: "비공개",
                time: "20ms",
                memory: "4020KB",
                message: "통과했습니다."
            }
        ]
    },
    {
        id: 202605030004,
        problemId: 12865,
        problemTitle: "평범한 배낭",
        status: "wrong",
        language: "C++17",
        user: "kimcode",
        timeMs: 20,
        memoryKb: 4256,
        codeLength: 1020,
        submittedAt: "2026-05-03T12:15:00",
        submittedAtText: "2026.05.03 12:15",
        note: "1차원 DP 갱신 방향 오류",
        tags: ["DP", "Knapsack"],
        compileCommand: "g++ -std=c++17 -O2 -pipe -static -s -o main main.cpp",
        runCommand: "./main",
        sourceFile: "main.cpp",
        code: `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;
    vector<int> dp(k + 1);

    for (int i = 0; i < n; i++) {
        int w, v;
        cin >> w >> v;
        for (int weight = w; weight <= k; weight++) {
            dp[weight] = max(dp[weight], dp[weight - w] + v);
        }
    }

    cout << dp[k] << '\\n';
    return 0;
}
`,
        compileLog: "Compilation completed successfully.",
        judgeLog: [
            "[12:15:01] queued submission #202605030004",
            "[12:15:01] compile started",
            "[12:15:02] compile success",
            "[12:15:02] sample tests started",
            "[12:15:02] sample accepted",
            "[12:15:03] hidden test #3 failed: wrong answer"
        ],
        cases: [
            {
                id: "sample-1",
                name: "예제 1",
                status: "accepted",
                input: "4 7\n6 13\n4 8\n3 6\n5 12",
                expectedOutput: "14",
                actualOutput: "14",
                time: "1ms",
                memory: "2024KB",
                message: "예제는 통과했습니다."
            },
            {
                id: "hidden-3",
                name: "Hidden 3",
                status: "wrong",
                input: "비공개",
                expectedOutput: "비공개",
                actualOutput: "비공개",
                time: "20ms",
                memory: "4256KB",
                message: "0/1 배낭에서 같은 물건이 중복 선택되는 케이스가 발생했습니다."
            }
        ]
    },
    {
        id: 202605030015,
        problemId: 12865,
        problemTitle: "평범한 배낭",
        status: "compile",
        language: "JavaScript",
        user: "kimcode",
        timeMs: null,
        memoryKb: null,
        codeLength: 2310,
        submittedAt: "2026-05-03T12:22:00",
        submittedAtText: "2026.05.03 12:22",
        note: "Node.js 코드 문법 오류",
        tags: ["DP", "Knapsack"],
        compileCommand: "node --check main.js",
        runCommand: "node main.js",
        sourceFile: "main.js",
        code: `const fs = require("fs");
const input = fs.readFileSync(0, "utf8").trim().split(/\\s+/).map(Number);

let index = 0;
const n = input[index++];
const k = input[index++];
const dp = Array(k + 1).fill(0);

for (let i = 0; i < n; i++) {
  const w = input[index++];
  const v = input[index++];
  for (let weight = k; weight >= w; weight--) {
    dp[weight] = Math.max(dp[weight], dp[weight - w] + v);
  }
}

console.log(dp[k]
`,
        compileLog: "SyntaxError: missing ) after argument list\n    at main.js:17:20",
        judgeLog: [
            "[12:22:01] queued submission #202605030015",
            "[12:22:01] syntax check started: node --check main.js",
            "[12:22:01] compile failed: missing ) after argument list"
        ],
        cases: [
            {
                id: "compile",
                name: "컴파일",
                status: "compile",
                input: "-",
                expectedOutput: "-",
                actualOutput: "-",
                time: "-",
                memory: "-",
                message: "17번째 줄에서 닫는 괄호가 누락되었습니다."
            }
        ]
    },
    {
        id: 202605030017,
        problemId: 1000,
        problemTitle: "두 수의 합",
        status: "accepted",
        language: "Dart",
        user: "dartuser",
        timeMs: 18,
        memoryKb: 6020,
        codeLength: 214,
        submittedAt: "2026-05-03T12:27:00",
        submittedAtText: "2026.05.03 12:27",
        note: "Dart 표준 입력 처리 확인 후 통과",
        tags: ["Implementation", "Math", "Dart"],
        compileCommand: "dart analyze main.dart",
        runCommand: "dart main.dart",
        sourceFile: "main.dart",
        code: `import 'dart:io';

void main() {
  final input = stdin.readAsStringSync().trim().split(RegExp(r'\\s+'));

  final a = int.parse(input[0]);
  final b = int.parse(input[1]);

  print(a + b);
}
`,
        compileLog: "No issues found.",
        judgeLog: [
            "[12:27:01] queued submission #202605030017",
            "[12:27:01] dart analyze started",
            "[12:27:02] analyze success",
            "[12:27:02] sample tests started",
            "[12:27:02] hidden tests started",
            "[12:27:03] all tests accepted"
        ],
        cases: [
            {
                id: "sample-1",
                name: "예제 1",
                status: "accepted",
                input: "1 2",
                expectedOutput: "3",
                actualOutput: "3",
                time: "2ms",
                memory: "5120KB",
                message: "예제 출력과 일치합니다."
            },
            {
                id: "hidden-1",
                name: "Hidden 1",
                status: "accepted",
                input: "비공개",
                expectedOutput: "비공개",
                actualOutput: "비공개",
                time: "18ms",
                memory: "6020KB",
                message: "통과했습니다."
            }
        ]
    },
    {
        id: 202605030018,
        problemId: 1000,
        problemTitle: "두 수의 합",
        status: "accepted",
        language: "C# 12",
        user: "csharpuser",
        timeMs: 25,
        memoryKb: 12000,
        codeLength: 430,
        submittedAt: "2026-05-03T12:30:00",
        submittedAtText: "2026.05.03 12:30",
        note: "C# 표준 입력 처리 확인 후 통과",
        tags: ["Implementation", "Math", "CSharp"],
        compileCommand: "dotnet build -c Release",
        runCommand: "dotnet run -c Release --no-build",
        sourceFile: "Main.cs",
        code: `using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        var input = Console.In.ReadToEnd()
            .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToArray();

        Console.WriteLine(input[0] + input[1]);
    }
}
`,
        compileLog: "Build succeeded.",
        judgeLog: [
            "[12:30:01] queued submission #202605030018",
            "[12:30:01] dotnet build started",
            "[12:30:02] build success",
            "[12:30:02] sample tests started",
            "[12:30:02] hidden tests started",
            "[12:30:03] all tests accepted"
        ],
        cases: [
            {
                id: "sample-1",
                name: "예제 1",
                status: "accepted",
                input: "1 2",
                expectedOutput: "3",
                actualOutput: "3",
                time: "3ms",
                memory: "12000KB",
                message: "예제 출력과 일치합니다."
            },
            {
                id: "hidden-1",
                name: "Hidden 1",
                status: "accepted",
                input: "비공개",
                expectedOutput: "비공개",
                actualOutput: "비공개",
                time: "25ms",
                memory: "12000KB",
                message: "통과했습니다."
            }
        ]
    }
];

const tabLabels: Record<DetailTab, string> = {
    overview: "요약",
    code: "코드",
    cases: "테스트 결과",
    log: "채점 로그"
};

function findSubmission(id: number) {
    return submissions.find((submission) => submission.id === id);
}

function formatTime(timeMs: number | null) {
    return timeMs === null ? "-" : `${timeMs}ms`;
}

function formatMemory(memoryKb: number | null) {
    if (memoryKb === null) return "-";
    return `${memoryKb.toLocaleString()}KB`;
}

function getStatusTone(status: SubmissionStatus) {
    switch (status) {
        case "accepted":
            return "green" as const;
        case "wrong":
        case "compile":
        case "runtime":
        case "timeLimit":
            return "red" as const;
        case "pending":
        case "judging":
            return "orange" as const;
        default:
            return "blue" as const;
    }
}

function getStatusNotice(submission: SubmissionDetail) {
    switch (submission.status) {
        case "accepted":
            return {
                variant: "success" as const,
                title: "맞았습니다",
                message: "모든 테스트 케이스를 통과했습니다."
            };
        case "wrong":
            return {
                variant: "danger" as const,
                title: "틀렸습니다",
                message: submission.note || "출력이 정답과 다른 테스트 케이스가 있습니다."
            };
        case "compile":
            return {
                variant: "danger" as const,
                title: "컴파일 에러",
                message: "컴파일 또는 문법 검사 단계에서 실패했습니다."
            };
        case "runtime":
            return {
                variant: "danger" as const,
                title: "런타임 에러",
                message: "실행 중 예외 또는 비정상 종료가 발생했습니다."
            };
        case "timeLimit":
            return {
                variant: "warning" as const,
                title: "시간 초과",
                message: "제한 시간 안에 실행이 완료되지 않았습니다."
            };
        case "pending":
        case "judging":
            return {
                variant: "info" as const,
                title: "채점 진행 중",
                message: "채점이 아직 완료되지 않았습니다."
            };
        default:
            return {
                variant: "info" as const,
                title: "제출 상태",
                message: "제출 상태를 확인하세요."
            };
    }
}

function TabButton({
                       tab,
                       activeTab,
                       onClick
                   }: {
    tab: DetailTab;
    activeTab: DetailTab;
    onClick: (tab: DetailTab) => void;
}) {
    return (
        <button
            type="button"
            onClick={() => onClick(tab)}
            className={`rounded-2xl px-4 py-3 text-sm font-black transition ${
                activeTab === tab
                    ? "bg-slate-950 text-white"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-950"
            }`}
        >
            {tabLabels[tab]}
        </button>
    );
}

function OverviewTab({ submission }: { submission: SubmissionDetail }) {
    const notice = getStatusNotice(submission);
    const acceptedCases = submission.cases.filter((item) => item.status === "accepted").length;
    const caseProgress = Math.round((acceptedCases / Math.max(submission.cases.length, 1)) * 100);

    return (
        <div className="space-y-4">
            <Notice variant={notice.variant} title={notice.title}>
                {notice.message}
            </Notice>

            <Card className="p-5">
                <div className="mb-4 flex items-center justify-between gap-3">
                    <h3 className="text-xl font-black text-slate-950">제출 정보</h3>
                    <SubmissionStatusBadge value={submission.status} />
                </div>

                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                    <InfoBox label="제출 번호" value={`#${submission.id}`} icon={History} />
                    <InfoBox
                        label="문제"
                        value={`${submission.problemId}. ${submission.problemTitle}`}
                        icon={BookOpen}
                        href={`/problems/${submission.problemId}`}
                    />
                    <InfoBox label="언어" value={submission.language} icon={Code2} />
                    <InfoBox label="실행 시간" value={formatTime(submission.timeMs)} icon={Timer} />
                    <InfoBox label="메모리" value={formatMemory(submission.memoryKb)} icon={MemoryStick} />
                    <InfoBox label="코드 길이" value={`${submission.codeLength.toLocaleString()}B`} icon={FileCode2} />
                    <InfoBox label="제출자" value={submission.user} icon={UserRound} />
                    <InfoBox label="제출 시간" value={submission.submittedAtText} icon={Clock3} />
                    <InfoBox label="파일" value={submission.sourceFile} icon={Terminal} />
                </div>
            </Card>

            <Card className="p-5">
                <div className="mb-4 flex items-center justify-between gap-3">
                    <h3 className="text-xl font-black text-slate-950">테스트 통과율</h3>
                    <span className="text-sm font-black text-blue-600">{caseProgress}%</span>
                </div>

                <ProgressBar
                    value={caseProgress}
                    barClassName={caseProgress === 100 ? "bg-emerald-600" : "bg-orange-500"}
                />

                <div className="mt-4 grid grid-cols-3 gap-3">
                    <MiniStat label="전체" value={`${submission.cases.length}`} />
                    <MiniStat label="통과" value={`${acceptedCases}`} />
                    <MiniStat label="실패" value={`${submission.cases.length - acceptedCases}`} />
                </div>
            </Card>

            <Card className="p-5">
                <h3 className="text-xl font-black text-slate-950">메모</h3>
                <p className="mt-3 text-sm leading-7 text-slate-500">{submission.note}</p>

                <div className="mt-4 flex flex-wrap gap-2">
                    {submission.tags.map((tag) => (
                        <Badge key={tag}>#{tag}</Badge>
                    ))}
                </div>
            </Card>
        </div>
    );
}

function InfoBox({
                     label,
                     value,
                     icon: Icon,
                     href
                 }: {
    label: string;
    value: string;
    icon: ComponentType<{ className?: string }>;
    href?: string;
}) {
    const content = (
        <div className="flex items-start gap-3 rounded-2xl bg-slate-50 p-4 transition hover:bg-blue-50">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white text-blue-600 shadow-sm">
                <Icon className="h-5 w-5" />
            </div>

            <div className="min-w-0">
                <p className="text-xs font-black text-slate-400">{label}</p>
                <p className="mt-1 break-all text-sm font-black text-slate-800">{value}</p>
            </div>
        </div>
    );

    return href ? <Link href={href}>{content}</Link> : content;
}

function CodeTab({
                     submission,
                     onCopy
                 }: {
    submission: SubmissionDetail;
    onCopy: () => void;
}) {
    return (
        <Card className="relative z-10 overflow-visible">
            <div className="flex flex-col gap-3 rounded-t-3xl border-b border-slate-100 bg-white p-4 xl:flex-row xl:items-center xl:justify-between">
                <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="blue">{submission.language}</Badge>
                    <Badge>{submission.sourceFile}</Badge>
                    <Badge>{submission.codeLength.toLocaleString()}B</Badge>
                    <Badge>Read Only</Badge>
                </div>

                <div className="flex flex-wrap gap-2">
                    <AppButton variant="secondary" icon={Copy} onClick={onCopy}>
                        코드 복사
                    </AppButton>

                    <AppLinkButton
                        href={`/problems/${submission.problemId}/solve`}
                        variant="primary"
                        iconRight={ArrowRight}
                    >
                        이 코드로 다시 풀기
                    </AppLinkButton>
                </div>
            </div>

            <div className="relative min-h-[720px] overflow-visible rounded-b-3xl bg-slate-950">
                <JudgeMonacoEditor
                    key={`${submission.id}-${submission.language}`}
                    height="720px"
                    theme="vs-dark"
                    language={monacoLanguageMap[submission.language]}
                    judgeLanguage={submission.language}
                    fileName={submission.sourceFile}
                    value={submission.code}
                    onChange={() => {
                        // 제출 상세 화면은 읽기 전용입니다.
                    }}
                    readOnly
                    enableLsp={false}
                    options={{
                        domReadOnly: true,
                        minimap: {
                            enabled: true
                        },
                        fixedOverflowWidgets: true
                    }}
                />
            </div>
        </Card>
    );
}

function CasesTab({ cases }: { cases: CaseResult[] }) {
    return (
        <div className="space-y-4">
            {cases.map((item) => (
                <Card key={item.id} className="overflow-hidden">
                    <div className="flex flex-col gap-3 border-b border-slate-100 bg-slate-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex flex-wrap items-center gap-2">
                            <SubmissionStatusBadge value={item.status} />
                            <span className="font-black text-slate-950">{item.name}</span>
                        </div>

                        <div className="flex flex-wrap gap-2 text-xs font-black text-slate-400">
                            <Badge>{item.time}</Badge>
                            <Badge>{item.memory}</Badge>
                        </div>
                    </div>

                    <div className="grid gap-0 xl:grid-cols-3">
                        <CaseBlock title="입력" value={item.input} />
                        <CaseBlock title="기대 출력" value={item.expectedOutput} />
                        <CaseBlock title="실제 출력" value={item.actualOutput} />
                    </div>

                    <div className="border-t border-slate-100 p-5">
                        <p className="text-sm leading-7 text-slate-500">{item.message}</p>
                    </div>
                </Card>
            ))}
        </div>
    );
}

function CaseBlock({ title, value }: { title: string; value: string }) {
    return (
        <div className="border-b border-slate-100 p-5 xl:border-b-0 xl:border-r last:xl:border-r-0">
            <h4 className="mb-3 font-black text-slate-950">{title}</h4>
            <pre className="max-h-60 overflow-auto rounded-2xl bg-slate-950 p-4 text-sm leading-7 text-slate-100">
                <code>{value}</code>
            </pre>
        </div>
    );
}

function LogTab({ submission }: { submission: SubmissionDetail }) {
    return (
        <div className="space-y-4">
            <Card className="p-5">
                <h3 className="text-xl font-black text-slate-950">컴파일 로그</h3>
                <pre className="mt-4 overflow-x-auto rounded-2xl bg-slate-950 p-4 text-sm leading-7 text-slate-100">
                    <code>{submission.compileLog}</code>
                </pre>
            </Card>

            <Card className="p-5">
                <h3 className="text-xl font-black text-slate-950">채점 로그</h3>
                <div className="mt-4 space-y-2">
                    {submission.judgeLog.map((line) => (
                        <div
                            key={line}
                            className="rounded-2xl bg-slate-50 px-4 py-3 font-mono text-sm font-bold text-slate-600"
                        >
                            {line}
                        </div>
                    ))}
                </div>
            </Card>

            <Card className="p-5">
                <h3 className="text-xl font-black text-slate-950">실행 명령</h3>
                <div className="mt-4 grid gap-3 xl:grid-cols-2">
                    <CommandBox label="Compile" value={submission.compileCommand} />
                    <CommandBox label="Run" value={submission.runCommand} />
                </div>
            </Card>
        </div>
    );
}

function CommandBox({ label, value }: { label: string; value: string }) {
    return (
        <div className="rounded-2xl bg-slate-50 p-4">
            <p className="text-xs font-black text-slate-400">{label}</p>
            <pre className="mt-2 overflow-x-auto font-mono text-sm font-bold text-slate-700">
                <code>{value}</code>
            </pre>
        </div>
    );
}

function ResultTimeline({ submission }: { submission: SubmissionDetail }) {
    const steps = [
        {
            label: "제출 접수",
            done: true,
            icon: History
        },
        {
            label: "컴파일",
            done: submission.status !== "pending" && submission.status !== "judging",
            icon: Terminal
        },
        {
            label: "테스트 실행",
            done:
                submission.status !== "compile" &&
                submission.status !== "pending" &&
                submission.status !== "judging",
            icon: Play
        },
        {
            label: "결과 확정",
            done: submission.status !== "pending" && submission.status !== "judging",
            icon: submission.status === "accepted" ? CheckCircle2 : XCircle
        }
    ];

    return (
        <SidePanel title="채점 단계" badge={<Sparkles className="h-5 w-5 text-blue-600" />}>
            <div className="space-y-2">
                {steps.map((step, index) => {
                    const Icon = step.icon;

                    return (
                        <div
                            key={step.label}
                            className="flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3"
                        >
                            <div
                                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                                    step.done ? "bg-blue-600 text-white" : "bg-white text-slate-400"
                                }`}
                            >
                                <Icon className="h-4 w-4" />
                            </div>

                            <div>
                                <p className="text-sm font-black text-slate-800">
                                    {index + 1}. {step.label}
                                </p>
                                <p className="mt-0.5 text-xs font-bold text-slate-400">
                                    {step.done ? "완료" : "대기"}
                                </p>
                            </div>
                        </div>
                    );
                })}
            </div>
        </SidePanel>
    );
}

function QuickLink({
                       href,
                       label,
                       icon: Icon
                   }: {
    href: string;
    label: string;
    icon: ComponentType<{ className?: string }>;
}) {
    return (
        <Link
            href={href}
            className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-blue-50 hover:text-blue-700"
        >
            <span className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                {label}
            </span>
            <ChevronRight className="h-4 w-4" />
        </Link>
    );
}

function NotFoundSubmission({ id }: { id: string }) {
    return (
        <AppShell
            title="제출을 찾을 수 없습니다"
            description="요청한 제출 기록이 현재 로컬 데이터에 없습니다."
        >
            <EmptyState
                title={`#${id} 제출을 찾을 수 없습니다.`}
                description="제출 번호를 다시 확인하거나 전체 제출 기록으로 돌아가세요."
                icon={Search}
                action={
                    <AppLinkButton href="/submissions" variant="dark" icon={ArrowLeft}>
                        제출 기록으로 돌아가기
                    </AppLinkButton>
                }
            />
        </AppShell>
    );
}

function InfoLine({ label, value }: { label: string; value: string }) {
    return (
        <div className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm font-bold">
            <span className="text-slate-400">{label}</span>
            <span className="break-all text-right text-slate-700">{value}</span>
        </div>
    );
}

export default function SubmissionDetailPage() {
    const params = useParams<{ id: string }>();
    const id = String(params.id ?? "");
    const submissionId = Number(id);
    const submission = Number.isFinite(submissionId) ? findSubmission(submissionId) : undefined;
    const [activeTab, setActiveTab] = useState<DetailTab>("overview");
    const [message, setMessage] = useState<string | null>(null);

    const acceptedCases = useMemo(() => {
        if (!submission) return 0;
        return submission.cases.filter((item) => item.status === "accepted").length;
    }, [submission]);

    if (!submission) {
        return <NotFoundSubmission id={id} />;
    }

    const caseProgress = Math.round((acceptedCases / Math.max(submission.cases.length, 1)) * 100);
    const statusTone = getStatusTone(submission.status);

    const handleCopyCode = async () => {
        await navigator.clipboard.writeText(submission.code);
        setMessage("코드를 클립보드에 복사했습니다.");
        window.setTimeout(() => setMessage(null), 1800);
    };

    return (
        <AppShell
            title={`제출 #${submission.id}`}
            description={`${submission.problemTitle} · ${submission.language} · ${submission.submittedAtText}`}
        >
            <div className="space-y-6">
                <PageHero
                    eyebrow={
                        <>
                            <Link
                                href="/submissions"
                                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-black text-white transition hover:bg-white/15"
                            >
                                <ArrowLeft className="h-3.5 w-3.5" />
                                제출 기록
                            </Link>
                            <Badge variant="blue">Submission</Badge>
                            <SubmissionStatusBadge value={submission.status} />
                            <Badge>{submission.language}</Badge>
                        </>
                    }
                    title={`제출 #${submission.id}`}
                    description={`${submission.problemId}. ${submission.problemTitle} · ${submission.note}`}
                    icon={ListChecks}
                    rightTitle="결과"
                    rightValue={
                        submission.status === "accepted"
                            ? "AC"
                            : submission.status === "wrong"
                                ? "WA"
                                : submission.status === "compile"
                                    ? "CE"
                                    : submission.status
                    }
                    rightCaption={`${formatTime(submission.timeMs)} · ${formatMemory(submission.memoryKb)}`}
                    metrics={[
                        {
                            label: "문제",
                            value: `#${submission.problemId}`
                        },
                        {
                            label: "언어",
                            value: submission.language
                        },
                        {
                            label: "테스트",
                            value: `${acceptedCases}/${submission.cases.length}`
                        }
                    ]}
                    actions={
                        <>
                            <AppLinkButton
                                href={`/problems/${submission.problemId}/solve`}
                                variant="primary"
                                size="lg"
                                iconRight={ArrowRight}
                            >
                                다시 풀기
                            </AppLinkButton>
                            <AppLinkButton
                                href={`/problems/${submission.problemId}`}
                                variant="white"
                                size="lg"
                                icon={BookOpen}
                            >
                                문제 보기
                            </AppLinkButton>
                        </>
                    }
                />

                {message && (
                    <Notice variant="success" title="알림">
                        {message}
                    </Notice>
                )}

                <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <StatCard
                        label="결과"
                        value={
                            submission.status === "accepted"
                                ? "맞았습니다"
                                : submission.status === "wrong"
                                    ? "틀렸습니다"
                                    : submission.status === "compile"
                                        ? "컴파일 에러"
                                        : submission.status
                        }
                        caption="채점 결과"
                        icon={submission.status === "accepted" ? CheckCircle2 : XCircle}
                        tone={statusTone}
                    />
                    <StatCard
                        label="실행 시간"
                        value={formatTime(submission.timeMs)}
                        caption="최대 실행 시간"
                        icon={Timer}
                        tone="blue"
                    />
                    <StatCard
                        label="메모리"
                        value={formatMemory(submission.memoryKb)}
                        caption="최대 사용 메모리"
                        icon={MemoryStick}
                        tone="orange"
                    />
                    <StatCard
                        label="코드 길이"
                        value={`${submission.codeLength.toLocaleString()}B`}
                        caption={submission.sourceFile}
                        icon={FileCode2}
                    />
                </section>

                <section className="grid gap-6 2xl:grid-cols-[1fr_380px]">
                    <div className="space-y-5">
                        <Card className="p-2">
                            <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                                {(["overview", "code", "cases", "log"] as DetailTab[]).map((tab) => (
                                    <TabButton
                                        key={tab}
                                        tab={tab}
                                        activeTab={activeTab}
                                        onClick={setActiveTab}
                                    />
                                ))}
                            </div>
                        </Card>

                        {activeTab === "overview" && <OverviewTab submission={submission} />}
                        {activeTab === "code" && (
                            <CodeTab submission={submission} onCopy={handleCopyCode} />
                        )}
                        {activeTab === "cases" && <CasesTab cases={submission.cases} />}
                        {activeTab === "log" && <LogTab submission={submission} />}
                    </div>

                    <aside className="space-y-4">
                        <SidePanel title="결과 요약" badge={<Gauge className="h-5 w-5 text-blue-600" />}>
                            <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white">
                                <p className="text-sm font-black text-slate-300">테스트 통과율</p>
                                <p className="mt-1 text-5xl font-black">{caseProgress}%</p>
                                <ProgressBar
                                    value={caseProgress}
                                    className="mt-5 bg-white/10"
                                    barClassName={caseProgress === 100 ? "bg-emerald-500" : "bg-orange-500"}
                                />
                            </div>

                            <div className="mt-4 grid grid-cols-3 gap-3">
                                <MiniStat label="전체" value={`${submission.cases.length}`} />
                                <MiniStat label="통과" value={`${acceptedCases}`} />
                                <MiniStat label="실패" value={`${submission.cases.length - acceptedCases}`} />
                            </div>
                        </SidePanel>

                        <ResultTimeline submission={submission} />

                        <SidePanel title="문제 정보" badge={<BookOpen className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                <InfoLine label="문제" value={`${submission.problemId}. ${submission.problemTitle}`} />
                                <InfoLine label="제출자" value={submission.user} />
                                <InfoLine label="제출 시간" value={submission.submittedAtText} />
                                <InfoLine label="언어" value={submission.language} />
                            </div>

                            <div className="mt-4 flex flex-wrap gap-2">
                                {submission.tags.map((tag) => (
                                    <Badge key={tag}>#{tag}</Badge>
                                ))}
                            </div>
                        </SidePanel>

                        <SidePanel title="빠른 이동" badge={<Zap className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                <QuickLink
                                    href={`/problems/${submission.problemId}`}
                                    label="문제 상세"
                                    icon={BookOpen}
                                />
                                <QuickLink
                                    href={`/problems/${submission.problemId}/solve`}
                                    label="다시 풀기"
                                    icon={Play}
                                />
                                <QuickLink
                                    href={`/problems/${submission.problemId}/submissions`}
                                    label="이 문제 제출 기록"
                                    icon={History}
                                />
                                <QuickLink href="/submissions" label="전체 제출 기록" icon={ListChecks} />
                                <QuickLink href="/notes" label="오답노트" icon={NotebookPen} />
                            </div>
                        </SidePanel>

                        <Notice title="MVP 구현 메모" variant="info">
                            현재 `/submissions/[id]`는 샘플 제출 데이터 기반입니다.
                            실제 연결 시에는 `GET /api/submissions/:id`,
                            `GET /api/submissions/:id/cases`,
                            `POST /api/submissions/:id/rejudge`를 붙이면 됩니다.
                        </Notice>
                    </aside>
                </section>
            </div>
        </AppShell>
    );
}