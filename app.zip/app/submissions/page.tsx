"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { ComponentType } from "react";
import AppShell from "@/components/layout/AppShell";
import {
    AppLinkButton,
    Badge,
    Card,
    EmptyState,
    MiniStat,
    Notice,
    PageHero,
    ProgressBar,
    SidePanel,
    StatCard
} from "@/components/ui";
import {
    FilterPanel,
    FilterSelect,
    SearchInput
} from "@/components/forms";
import {
    ListHeader,
    ViewModeToggle,
    type ViewMode
} from "@/components/common";
import {
    SubmissionStatusBadge,
    type SubmissionStatus
} from "@/components/domain";
import {
    AlertTriangle,
    ArrowRight,
    BarChart3,
    BookOpen,
    CheckCircle2,
    ChevronRight,
    Clock3,
    Code2,
    Database,
    FileCode2,
    Flame,
    Gauge,
    History,
    ListChecks,
    NotebookPen,
    RotateCcw,
    Search,
    Sparkles,
    Target,
    Terminal,
    Timer,
    Trophy,
    UserRound,
    XCircle,
    Zap
} from "lucide-react";

type Language = "C++17" | "Python 3.12" | "Java 17" | "JavaScript";
type StatusFilter = "전체" | "맞았습니다" | "틀렸습니다" | "시간 초과" | "런타임 에러" | "컴파일 에러" | "채점 대기" | "채점 중";
type LanguageFilter = "전체" | Language;
type SortOption = "recent" | "oldest" | "time-asc" | "memory-asc" | "code-length-desc" | "problem-asc";

type SubmissionItem = {
    id: number;
    problemId: number;
    problemTitle: string;
    status: SubmissionStatus;
    language: Language;
    timeMs: number | null;
    memoryKb: number | null;
    codeLength: number;
    submittedAt: string;
    submittedAtText: string;
    user: string;
    note: string;
    tags: string[];
};

const submissions: SubmissionItem[] = [
    {
        id: 202605030014,
        problemId: 7576,
        problemTitle: "토마토",
        status: "accepted",
        language: "C++17",
        timeMs: 20,
        memoryKb: 4020,
        codeLength: 1488,
        submittedAt: "2026-05-03T12:02:00",
        submittedAtText: "2026.05.03 12:02",
        user: "kimcode",
        note: "다중 시작점 BFS 수정 후 통과",
        tags: ["BFS", "Graph", "Queue"]
    },
    {
        id: 202605030004,
        problemId: 12865,
        problemTitle: "평범한 배낭",
        status: "wrong",
        language: "C++17",
        timeMs: 20,
        memoryKb: 4256,
        codeLength: 1020,
        submittedAt: "2026-05-03T12:15:00",
        submittedAtText: "2026.05.03 12:15",
        user: "kimcode",
        note: "1차원 DP 갱신 방향 오류",
        tags: ["DP", "Knapsack"]
    },
    {
        id: 202605030015,
        problemId: 12865,
        problemTitle: "평범한 배낭",
        status: "compile",
        language: "JavaScript",
        timeMs: null,
        memoryKb: null,
        codeLength: 2310,
        submittedAt: "2026-05-03T12:22:00",
        submittedAtText: "2026.05.03 12:22",
        user: "kimcode",
        note: "Node.js 코드 문법 오류",
        tags: ["DP", "Knapsack"]
    },
    {
        id: 202605030003,
        problemId: 7576,
        problemTitle: "토마토",
        status: "wrong",
        language: "C++17",
        timeMs: 8,
        memoryKb: 3212,
        codeLength: 1342,
        submittedAt: "2026-05-03T11:20:00",
        submittedAtText: "2026.05.03 11:20",
        user: "kimcode",
        note: "초기 큐에 시작점을 하나만 넣음",
        tags: ["BFS", "Graph", "Queue"]
    },
    {
        id: 202605030013,
        problemId: 7576,
        problemTitle: "토마토",
        status: "wrong",
        language: "Python 3.12",
        timeMs: 84,
        memoryKb: 42128,
        codeLength: 1760,
        submittedAt: "2026-05-03T11:38:00",
        submittedAtText: "2026.05.03 11:38",
        user: "kimcode",
        note: "마지막 미익은 토마토 검사 누락",
        tags: ["BFS", "Graph", "Queue"]
    },
    {
        id: 202605030011,
        problemId: 2178,
        problemTitle: "미로 탐색",
        status: "pending",
        language: "C++17",
        timeMs: null,
        memoryKb: null,
        codeLength: 1420,
        submittedAt: "2026-05-03T11:05:00",
        submittedAtText: "2026.05.03 11:05",
        user: "kimcode",
        note: "채점 대기 중",
        tags: ["BFS", "Grid"]
    },
    {
        id: 202605030012,
        problemId: 2178,
        problemTitle: "미로 탐색",
        status: "runtime",
        language: "C++17",
        timeMs: 3,
        memoryKb: 2060,
        codeLength: 1394,
        submittedAt: "2026-05-03T10:58:00",
        submittedAtText: "2026.05.03 10:58",
        user: "kimcode",
        note: "좌표 범위 체크 누락",
        tags: ["BFS", "Grid"]
    },
    {
        id: 202605030002,
        problemId: 10828,
        problemTitle: "스택 명령 처리",
        status: "accepted",
        language: "C++17",
        timeMs: 12,
        memoryKb: 2144,
        codeLength: 812,
        submittedAt: "2026-05-03T10:42:00",
        submittedAtText: "2026.05.03 10:42",
        user: "kimcode",
        note: "ios::sync_with_stdio(false) 적용",
        tags: ["Stack", "Data Structure"]
    },
    {
        id: 202605030010,
        problemId: 10828,
        problemTitle: "스택 명령 처리",
        status: "timeLimit",
        language: "Java 17",
        timeMs: null,
        memoryKb: 36100,
        codeLength: 1290,
        submittedAt: "2026-05-03T10:36:00",
        submittedAtText: "2026.05.03 10:36",
        user: "kimcode",
        note: "Scanner 사용으로 시간 초과",
        tags: ["Stack", "Data Structure"]
    },
    {
        id: 202605030009,
        problemId: 1000,
        problemTitle: "두 수의 합",
        status: "accepted",
        language: "Python 3.12",
        timeMs: 4,
        memoryKb: 3120,
        codeLength: 48,
        submittedAt: "2026-05-03T10:31:00",
        submittedAtText: "2026.05.03 10:31",
        user: "kimcode",
        note: "Python 풀이 확인",
        tags: ["Implementation", "Math"]
    },
    {
        id: 202605030001,
        problemId: 1000,
        problemTitle: "두 수의 합",
        status: "accepted",
        language: "C++17",
        timeMs: 0,
        memoryKb: 2020,
        codeLength: 312,
        submittedAt: "2026-05-03T10:24:00",
        submittedAtText: "2026.05.03 10:24",
        user: "kimcode",
        note: "기본 입출력 통과",
        tags: ["Implementation", "Math"]
    }
];

const STATUS_OPTIONS: readonly StatusFilter[] = ["전체", "맞았습니다", "틀렸습니다", "시간 초과", "런타임 에러", "컴파일 에러", "채점 대기", "채점 중"];
const LANGUAGE_OPTIONS: readonly LanguageFilter[] = ["전체", "C++17", "Python 3.12", "Java 17", "JavaScript"];
const SORT_OPTIONS: readonly SortOption[] = ["recent", "oldest", "time-asc", "memory-asc", "code-length-desc", "problem-asc"];

const statusLabelToValue: Record<Exclude<StatusFilter, "전체">, SubmissionStatus> = {
    "맞았습니다": "accepted",
    "틀렸습니다": "wrong",
    "시간 초과": "timeLimit",
    "런타임 에러": "runtime",
    "컴파일 에러": "compile",
    "채점 대기": "pending",
    "채점 중": "judging"
};

const sortLabels: Record<SortOption, string> = {
    recent: "최근 제출순",
    oldest: "오래된 제출순",
    "time-asc": "실행 시간 낮은순",
    "memory-asc": "메모리 낮은순",
    "code-length-desc": "코드 길이 긴순",
    "problem-asc": "문제 번호 낮은순"
};

function formatTime(timeMs: number | null) {
    return timeMs === null ? "-" : `${timeMs}ms`;
}

function formatMemory(memoryKb: number | null) {
    if (memoryKb === null) return "-";
    return `${memoryKb.toLocaleString()}KB`;
}

function getAverageTime(items: SubmissionItem[]) {
    const values = items.map((item) => item.timeMs).filter((value): value is number => value !== null);
    if (values.length === 0) return 0;
    return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function getAverageMemory(items: SubmissionItem[]) {
    const values = items.map((item) => item.memoryKb).filter((value): value is number => value !== null);
    if (values.length === 0) return 0;
    return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function isErrorStatus(status: SubmissionStatus) {
    return status === "compile" || status === "runtime" || status === "timeLimit";
}

function SubmissionCard({ submission }: { submission: SubmissionItem }) {
    return (
        <Card hover className="p-5">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                <div className="min-w-0">
                    <div className="mb-3 flex flex-wrap items-center gap-2">
                        <SubmissionStatusBadge value={submission.status} />
                        <Badge variant="blue">{submission.language}</Badge>
                        <Badge>#{submission.id}</Badge>
                    </div>

                    <Link href={`/problems/${submission.problemId}`} className="text-xl font-black text-slate-950 transition hover:text-blue-600">
                        {submission.problemId}. {submission.problemTitle}
                    </Link>
                    <p className="mt-2 text-sm leading-7 text-slate-500">{submission.note}</p>

                    <div className="mt-4 flex flex-wrap gap-2">
                        {submission.tags.map((tag) => <Badge key={tag}>#{tag}</Badge>)}
                    </div>
                </div>

                <div className="grid min-w-full grid-cols-2 gap-3 sm:min-w-[360px]">
                    <MetricBox label="시간" value={formatTime(submission.timeMs)} />
                    <MetricBox label="메모리" value={formatMemory(submission.memoryKb)} />
                    <MetricBox label="코드" value={`${submission.codeLength.toLocaleString()}B`} />
                    <MetricBox label="제출자" value={submission.user} />
                </div>
            </div>

            <div className="mt-5 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                    <Clock3 className="h-4 w-4" />
                    {submission.submittedAtText}
                </div>
                <div className="flex flex-wrap gap-2">
                    <AppLinkButton href={`/submissions/${submission.id}`} variant="secondary" iconRight={ChevronRight}>
                        제출 상세
                    </AppLinkButton>
                    <AppLinkButton href={`/problems/${submission.problemId}/solve`} variant="primary" iconRight={ArrowRight}>
                        다시 풀기
                    </AppLinkButton>
                </div>
            </div>
        </Card>
    );
}

function MetricBox({ label, value }: { label: string; value: string }) {
    return (
        <div className="rounded-2xl bg-slate-50 p-4">
            <p className="text-xs font-bold text-slate-400">{label}</p>
            <p className="mt-1 font-black text-slate-950">{value}</p>
        </div>
    );
}

function SubmissionsTable({ items }: { items: SubmissionItem[] }) {
    return (
        <Card className="overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full min-w-[1180px] text-left text-sm">
                    <thead className="border-b border-slate-100 bg-slate-50 text-xs font-black uppercase tracking-wide text-slate-400">
                    <tr>
                        <th className="px-5 py-4">제출 번호</th>
                        <th className="px-5 py-4">문제</th>
                        <th className="px-5 py-4">결과</th>
                        <th className="px-5 py-4">언어</th>
                        <th className="px-5 py-4 text-right">시간</th>
                        <th className="px-5 py-4 text-right">메모리</th>
                        <th className="px-5 py-4 text-right">코드 길이</th>
                        <th className="px-5 py-4">제출자</th>
                        <th className="px-5 py-4">제출 시간</th>
                        <th className="px-5 py-4" />
                    </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-100">
                    {items.map((submission) => (
                        <tr key={submission.id} className="transition hover:bg-slate-50">
                            <td className="px-5 py-4">
                                <Link href={`/submissions/${submission.id}`} className="font-black text-slate-950 transition hover:text-blue-600">
                                    #{submission.id}
                                </Link>
                                <p className="mt-1 line-clamp-1 text-xs font-bold text-slate-400">{submission.note}</p>
                            </td>
                            <td className="px-5 py-4">
                                <Link href={`/problems/${submission.problemId}`} className="font-black text-slate-950 transition hover:text-blue-600">
                                    {submission.problemTitle}
                                </Link>
                                <p className="mt-1 text-xs font-bold text-slate-400">#{submission.problemId}</p>
                            </td>
                            <td className="px-5 py-4"><SubmissionStatusBadge value={submission.status} /></td>
                            <td className="px-5 py-4"><Badge variant="blue">{submission.language}</Badge></td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{formatTime(submission.timeMs)}</td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{formatMemory(submission.memoryKb)}</td>
                            <td className="px-5 py-4 text-right font-bold text-slate-600">{submission.codeLength.toLocaleString()}B</td>
                            <td className="px-5 py-4 font-bold text-slate-600">{submission.user}</td>
                            <td className="px-5 py-4 font-bold text-slate-500">{submission.submittedAtText}</td>
                            <td className="px-5 py-4 text-right">
                                <AppLinkButton href={`/submissions/${submission.id}`} size="sm" iconRight={ChevronRight}>
                                    상세
                                </AppLinkButton>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

function StatusDistributionPanel({ items }: { items: SubmissionItem[] }) {
    const accepted = items.filter((item) => item.status === "accepted").length;
    const wrong = items.filter((item) => item.status === "wrong").length;
    const error = items.filter((item) => isErrorStatus(item.status)).length;
    const pending = items.filter((item) => item.status === "pending" || item.status === "judging").length;
    const total = Math.max(items.length, 1);

    return (
        <SidePanel title="결과 분포" badge={<Gauge className="h-5 w-5 text-blue-600" />}>
            <div className="space-y-4">
                <DistributionRow label="맞았습니다" value={accepted} total={total} barClassName="bg-emerald-600" icon={CheckCircle2} />
                <DistributionRow label="틀렸습니다" value={wrong} total={total} barClassName="bg-rose-600" icon={XCircle} />
                <DistributionRow label="에러 / 초과" value={error} total={total} barClassName="bg-orange-500" icon={AlertTriangle} />
                <DistributionRow label="대기 / 채점" value={pending} total={total} barClassName="bg-blue-600" icon={RotateCcw} />
            </div>
        </SidePanel>
    );
}

function DistributionRow({
                             label,
                             value,
                             total,
                             barClassName,
                             icon: Icon
                         }: {
    label: string;
    value: number;
    total: number;
    barClassName: string;
    icon: ComponentType<{ className?: string }>;
}) {
    const percent = Math.round((value / total) * 100);

    return (
        <div>
            <div className="mb-2 flex items-center justify-between text-sm font-black">
                <span className="flex items-center gap-2 text-slate-700"><Icon className="h-4 w-4" />{label}</span>
                <span className="text-slate-500">{value}개</span>
            </div>
            <ProgressBar value={percent} barClassName={barClassName} />
        </div>
    );
}

function LanguagePanel({ items }: { items: SubmissionItem[] }) {
    const languages = LANGUAGE_OPTIONS.filter((language) => language !== "전체") as Language[];

    return (
        <SidePanel title="언어별 제출" badge={<Code2 className="h-5 w-5 text-blue-600" />}>
            <div className="space-y-3">
                {languages.map((language) => {
                    const count = items.filter((item) => item.language === language).length;
                    const percent = Math.round((count / Math.max(items.length, 1)) * 100);

                    return (
                        <div key={language}>
                            <div className="mb-2 flex items-center justify-between text-sm font-black">
                                <Badge variant="blue">{language}</Badge>
                                <span className="text-slate-500">{count}개</span>
                            </div>
                            <ProgressBar value={percent} />
                        </div>
                    );
                })}
            </div>
        </SidePanel>
    );
}

function RecentProblemPanel({ items }: { items: SubmissionItem[] }) {
    const problemMap = new Map<number, { title: string; count: number; accepted: number }>();

    items.forEach((item) => {
        const current = problemMap.get(item.problemId) ?? { title: item.problemTitle, count: 0, accepted: 0 };
        current.count += 1;
        if (item.status === "accepted") current.accepted += 1;
        problemMap.set(item.problemId, current);
    });

    const rows = Array.from(problemMap.entries())
        .map(([id, value]) => ({ id, ...value }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

    return (
        <SidePanel title="최근 많이 제출한 문제" badge={<FileCode2 className="h-5 w-5 text-blue-600" />}>
            <div className="space-y-2">
                {rows.map((row) => (
                    <Link key={row.id} href={`/problems/${row.id}`} className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3 transition hover:bg-blue-50">
                        <div className="min-w-0">
                            <p className="truncate text-sm font-black text-slate-800">{row.title}</p>
                            <p className="mt-0.5 text-xs font-bold text-slate-400">#{row.id}</p>
                        </div>
                        <div className="text-right text-xs font-black text-slate-500">
                            <p>{row.count}회</p>
                            <p className="mt-0.5 text-emerald-600">AC {row.accepted}</p>
                        </div>
                    </Link>
                ))}
            </div>
        </SidePanel>
    );
}

function QuickLink({ href, label, icon: Icon }: { href: string; label: string; icon: ComponentType<{ className?: string }> }) {
    return (
        <Link href={href} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-sm font-black text-slate-700 transition hover:bg-blue-50 hover:text-blue-700">
      <span className="flex items-center gap-2">
        <Icon className="h-4 w-4" />
          {label}
      </span>
            <ChevronRight className="h-4 w-4" />
        </Link>
    );
}

export default function SubmissionsPage() {
    const [keyword, setKeyword] = useState("");
    const [status, setStatus] = useState<StatusFilter>("전체");
    const [language, setLanguage] = useState<LanguageFilter>("전체");
    const [sort, setSort] = useState<SortOption>("recent");
    const [viewMode, setViewMode] = useState<ViewMode>("table");

    const filteredSubmissions = useMemo(() => {
        const lowerKeyword = keyword.trim().toLowerCase();

        const result = submissions.filter((submission) => {
            const matchesKeyword =
                !lowerKeyword ||
                String(submission.id).includes(lowerKeyword) ||
                String(submission.problemId).includes(lowerKeyword) ||
                submission.problemTitle.toLowerCase().includes(lowerKeyword) ||
                submission.user.toLowerCase().includes(lowerKeyword) ||
                submission.language.toLowerCase().includes(lowerKeyword) ||
                submission.note.toLowerCase().includes(lowerKeyword) ||
                submission.tags.some((tag) => tag.toLowerCase().includes(lowerKeyword));

            const matchesStatus = status === "전체" || submission.status === statusLabelToValue[status];
            const matchesLanguage = language === "전체" || submission.language === language;

            return matchesKeyword && matchesStatus && matchesLanguage;
        });

        return result.sort((a, b) => {
            switch (sort) {
                case "oldest":
                    return a.submittedAt.localeCompare(b.submittedAt);
                case "time-asc":
                    return (a.timeMs ?? Number.MAX_SAFE_INTEGER) - (b.timeMs ?? Number.MAX_SAFE_INTEGER);
                case "memory-asc":
                    return (a.memoryKb ?? Number.MAX_SAFE_INTEGER) - (b.memoryKb ?? Number.MAX_SAFE_INTEGER);
                case "code-length-desc":
                    return b.codeLength - a.codeLength;
                case "problem-asc":
                    return a.problemId - b.problemId;
                case "recent":
                default:
                    return b.submittedAt.localeCompare(a.submittedAt);
            }
        });
    }, [keyword, status, language, sort]);

    const acceptedCount = submissions.filter((submission) => submission.status === "accepted").length;
    const wrongCount = submissions.filter((submission) => submission.status === "wrong").length;
    const errorCount = submissions.filter((submission) => isErrorStatus(submission.status)).length;
    const pendingCount = submissions.filter((submission) => submission.status === "pending" || submission.status === "judging").length;
    const acceptedRate = Math.round((acceptedCount / Math.max(submissions.length, 1)) * 1000) / 10;
    const averageTime = getAverageTime(submissions);
    const averageMemory = getAverageMemory(submissions);

    const resetFilters = () => {
        setKeyword("");
        setStatus("전체");
        setLanguage("전체");
        setSort("recent");
    };

    return (
        <AppShell title="제출 기록" description="전체 문제 제출 결과를 검색하고 분석합니다.">
            <div className="space-y-6">
                <PageHero
                    eyebrow={
                        <>
                            <Badge variant="blue">Submissions</Badge>
                            <Badge>Judge History</Badge>
                            <Badge variant="green">AC {acceptedCount}</Badge>
                        </>
                    }
                    title="전체 제출 기록을 한눈에 확인하세요."
                    description="문제별 제출 결과, 사용 언어, 실행 시간, 메모리, 코드 길이를 검색하고 오답은 바로 다시 풀 수 있습니다."
                    icon={ListChecks}
                    rightTitle="전체 제출"
                    rightValue={submissions.length.toLocaleString()}
                    rightCaption={`통과율 ${acceptedRate}%`}
                    metrics={[
                        { label: "AC", value: `${acceptedCount}` },
                        { label: "WA", value: `${wrongCount}` },
                        { label: "Error", value: `${errorCount}` }
                    ]}
                    actions={
                        <>
                            <AppLinkButton href="/problems" variant="primary" size="lg" iconRight={ArrowRight}>문제 풀기</AppLinkButton>
                            <AppLinkButton href="/notes" variant="white" size="lg" icon={NotebookPen}>오답노트</AppLinkButton>
                        </>
                    }
                />

                <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    <StatCard label="전체 제출" value={submissions.length.toLocaleString()} caption={`대기 ${pendingCount}개 포함`} icon={ListChecks} />
                    <StatCard label="맞았습니다" value={acceptedCount.toLocaleString()} caption={`통과율 ${acceptedRate}%`} icon={CheckCircle2} tone="green" />
                    <StatCard label="평균 시간" value={`${averageTime}ms`} caption="실행 완료 제출 기준" icon={Timer} tone="blue" />
                    <StatCard label="평균 메모리" value={formatMemory(averageMemory)} caption="실행 완료 제출 기준" icon={Database} tone="orange" />
                </section>

                <FilterPanel
                    title="제출 기록 검색 / 필터"
                    onReset={resetFilters}
                    gridClassName="grid gap-3 xl:grid-cols-[1.4fr_180px_180px_190px_auto] xl:items-end"
                >
                    <SearchInput
                        value={keyword}
                        onChange={setKeyword}
                        placeholder="제출 번호, 문제 번호, 문제명, 언어, 태그, 메모 검색"
                    />
                    <FilterSelect label="결과" value={status} onChange={setStatus} options={STATUS_OPTIONS} />
                    <FilterSelect label="언어" value={language} onChange={setLanguage} options={LANGUAGE_OPTIONS} />
                    <FilterSelect label="정렬" value={sort} onChange={setSort} options={SORT_OPTIONS} />
                </FilterPanel>

                <section className="grid gap-6 2xl:grid-cols-[1fr_380px]">
                    <div className="space-y-4">
                        <ListHeader
                            title="제출 목록"
                            description={`검색 조건에 맞는 제출 ${filteredSubmissions.length.toLocaleString()}개가 표시됩니다. 현재 정렬: ${sortLabels[sort]}`}
                            right={<ViewModeToggle value={viewMode} onChange={setViewMode} />}
                        />

                        {filteredSubmissions.length === 0 ? (
                            <EmptyState
                                title="제출 기록을 찾을 수 없습니다."
                                description="검색어 또는 필터 조건을 변경해보세요."
                                icon={Search}
                                onReset={resetFilters}
                            />
                        ) : viewMode === "card" ? (
                            <div className="space-y-4">
                                {filteredSubmissions.map((submission) => <SubmissionCard key={submission.id} submission={submission} />)}
                            </div>
                        ) : (
                            <SubmissionsTable items={filteredSubmissions} />
                        )}
                    </div>

                    <aside className="space-y-4">
                        <SidePanel title="제출 요약" badge={<BarChart3 className="h-5 w-5 text-blue-600" />}>
                            <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white">
                                <p className="text-sm font-black text-slate-300">통과율</p>
                                <p className="mt-1 text-5xl font-black">{acceptedRate}%</p>
                                <ProgressBar value={acceptedRate} className="mt-5 bg-white/10" />
                            </div>
                            <div className="mt-4 grid grid-cols-3 gap-3">
                                <MiniStat label="AC" value={`${acceptedCount}`} />
                                <MiniStat label="WA" value={`${wrongCount}`} />
                                <MiniStat label="Error" value={`${errorCount}`} />
                            </div>
                        </SidePanel>

                        <StatusDistributionPanel items={submissions} />
                        <LanguagePanel items={submissions} />
                        <RecentProblemPanel items={submissions} />

                        <SidePanel title="추천 행동" badge={<Sparkles className="h-5 w-5 text-blue-600" />}>
                            <div className="space-y-2">
                                <QuickLink href="/notes" label="오답노트 정리" icon={NotebookPen} />
                                <QuickLink href="/problems?tag=bfs" label="BFS 문제 다시 풀기" icon={Target} />
                                <QuickLink href="/sets" label="문제 세트 보기" icon={Trophy} />
                                <QuickLink href="/dashboard" label="대시보드" icon={Gauge} />
                            </div>
                        </SidePanel>

                        <Notice title="MVP 구현 메모" variant="info">
                            현재 `/submissions`는 샘플 제출 데이터 기반입니다. 실제 연결 시에는 `GET /api/submissions`, `GET /api/submissions/:id`, `GET /api/problems/:id/submissions`를 붙이면 됩니다.
                        </Notice>
                    </aside>
                </section>
            </div>
        </AppShell>
    );
}
