
"use client";

import AppShell from "@/components/layout/AppShell";
import { Badge, MiniStat, PageHero, ProgressBar, SectionHeader, SidePanel, StatCard, AppLinkButton } from "@/components/ui";
import { ActivityList, ProblemSetCard, RankingList, TestCard } from "@/components/domain";
import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  CalendarDays,
  CirclePlay,
  Code2,
  Database,
  Medal,
  Play,
  Trophy,
  UsersRound
} from "lucide-react";

const STATS = [
  { label: "등록 문제", value: "2,481", caption: "알고리즘 / 자료구조 / SQL", icon: BookOpen },
  { label: "진행 테스트", value: "12", caption: "현재 응시 가능한 테스트", icon: CirclePlay },
  { label: "오늘 제출", value: "186", caption: "최근 24시간 기준", icon: BarChart3 },
  { label: "참여자", value: "1,284", caption: "누적 응시자 수", icon: UsersRound }
];

const TESTS = [
  { title: "2026 상반기 알고리즘 모의 테스트", category: "모의고사", level: "중급" as const, duration: "120분", problemCount: 5, participants: "328명", status: "진행 가능" as const, href: "/tests" },
  { title: "자료구조 집중 평가", category: "실전 대비", level: "중급" as const, duration: "90분", problemCount: 4, participants: "184명", status: "마감 임박" as const, href: "/tests" },
  { title: "초급 구현 문제 세트", category: "연습", level: "초급" as const, duration: "60분", problemCount: 6, participants: "512명", status: "진행 가능" as const, href: "/tests" }
];

const PROBLEM_SETS = [
  { title: "입문자를 위한 구현 30제", description: "입출력, 조건문, 반복문, 문자열 처리 중심의 기본기 세트입니다.", count: 30, level: "Easy" as const, tags: ["구현", "문자열", "수학"], href: "/sets" },
  { title: "BFS / DFS 그래프 탐색", description: "그래프 순회, 최단 거리, 격자 탐색 문제를 단계별로 연습합니다.", count: 24, level: "Medium" as const, tags: ["그래프", "BFS", "DFS"], href: "/sets" },
  { title: "동적 계획법 핵심 유형", description: "점화식 설계와 메모이제이션 감각을 키우는 DP 문제 모음입니다.", count: 18, level: "Hard" as const, tags: ["DP", "최적화", "점화식"], href: "/sets" }
];

const ACTIVITIES = [
  { title: "문제 데이터 동기화 완료", description: "2,481개 문제 인덱스가 정상적으로 생성되었습니다.", time: "방금 전", icon: Database },
  { title: "Python 3.12 실행 환경 추가", description: "풀이 화면에서 Python 3.12를 선택할 수 있습니다.", time: "오늘 10:30", icon: Code2 },
  { title: "알고리즘 모의 테스트 예정", description: "오늘 추천 테스트로 5문제 세트가 준비되었습니다.", time: "오늘 09:00", icon: CalendarDays }
];

const RANKINGS = [
  { rank: 1, name: "algorithm_master", score: "1,850", href: "/profile/algo_master" },
  { rank: 2, name: "code_wizard", score: "1,780", href: "/profile/wizard_dev" },
  { rank: 3, name: "solve_it", score: "1,720", href: "/ranking" },
  { rank: 4, name: "dev_runner", score: "1,650", href: "/ranking" }
];

export default function HomePage() {
  return (
      <AppShell title="메인 대시보드" description="코딩 테스트와 문제 풀이 현황을 한눈에 확인합니다.">
        <div className="space-y-6">
          <PageHero
              eyebrow={
                <>
                  <Badge variant="blue">Local Judge</Badge>
                  <Badge>문제 검색</Badge>
                  <Badge>실시간 채점</Badge>
                </>
              }
              title="코딩 테스트를 연습하고, 제출하고, 결과를 바로 확인하세요."
              description="다운받은 문제 데이터를 기반으로 로컬 환경에서 문제 검색, 풀이, 제출 기록, 학습 현황을 관리할 수 있는 코딩 테스트 플랫폼입니다."
              icon={Trophy}
              rightTitle="현재 추천 테스트"
              rightValue="5문제"
              rightCaption="알고리즘 모의 테스트"
              metrics={[
                { label: "문제", value: "5개" },
                { label: "시간", value: "120분" },
                { label: "난이도", value: "중급" }
              ]}
              actions={
                <>
                  <AppLinkButton href="/problems" variant="primary" size="lg" iconRight={ArrowRight}>문제 풀기 시작</AppLinkButton>
                  <AppLinkButton href="/tests" variant="white" size="lg">모의 테스트 보기</AppLinkButton>
                </>
              }
          />

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {STATS.map((item) => <StatCard key={item.label} {...item} />)}
          </section>

          <section className="grid gap-6 xl:grid-cols-[1fr_380px]">
            <div className="space-y-6">
              <section>
                <SectionHeader title="진행 가능한 테스트" description="응시 가능한 테스트와 추천 평가를 확인합니다." href="/tests" />
                <div className="space-y-3">
                  {TESTS.map((item) => <TestCard key={item.title} item={item} />)}
                </div>
              </section>

              <section>
                <SectionHeader title="추천 문제 세트" description="주제별로 묶은 연습 문제를 단계적으로 풀 수 있습니다." href="/sets" />
                <div className="grid gap-4 lg:grid-cols-3">
                  {PROBLEM_SETS.map((item) => <ProblemSetCard key={item.title} item={item} />)}
                </div>
              </section>
            </div>

            <aside className="space-y-4">
              <SidePanel title="나의 학습 현황" badge={<Badge variant="blue">이번 주</Badge>}>
                <div className="space-y-4">
                  <div>
                    <div className="mb-2 flex items-center justify-between text-sm font-bold">
                      <span className="text-slate-500">목표 달성률</span>
                      <span className="text-slate-950">72%</span>
                    </div>
                    <ProgressBar value={72} />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <MiniStat label="해결" value="18" />
                    <MiniStat label="제출" value="43" />
                    <MiniStat label="정답률" value="81%" />
                  </div>
                </div>
              </SidePanel>

              <SidePanel title="실시간 랭킹" href="/ranking" badge={<Medal className="h-5 w-5 text-amber-500" />}>
                <RankingList items={RANKINGS} />
              </SidePanel>

              <SidePanel title="최근 활동" badge={<Badge variant="blue">실시간</Badge>}>
                <ActivityList items={ACTIVITIES} />
              </SidePanel>
            </aside>
          </section>
        </div>
      </AppShell>
  );
}
